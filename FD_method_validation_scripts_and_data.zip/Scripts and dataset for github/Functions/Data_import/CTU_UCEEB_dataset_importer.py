# -*- coding: utf-8 -*-
"""
Created on Tue Jul 19 11:22:22 2022

@author: GQ05XY
"""
import os
import pandas as pd

def CTU_UCEEB_dataset_importer(Data_subset):
    
    # if Data_subset == 0 ; AHU1.xlsx is selected (recommended)
    # if Data_subset == 1 ; AHU18.xlsx is selected (recommended)
    # if Data_subset == 2 ; AHU23.xlsx is selected (dataset must be cleaned before use)
    # if Data_subset == 3 ; AHU24.xlsx is selected (dataset must be cleaned before use)
    #Teoretically there are also dataset AHU2 and AHU8, but their data is not good enough
    

    folder = "CTU_UCEEB_dataset"
    if Data_subset == 0:
        file_name = "AHU1.xlsx"
    elif Data_subset == 1:
        file_name = "AHU18.xlsx"
    elif Data_subset == 2:
        file_name = "AHU23.xlsx"
    elif Data_subset == 3:
        file_name = "AHU24.xlsx"
    
    
    data_path = os.getcwd()
    data_path = data_path.split("\\")
    cut_folder = data_path.index("Scripts and dataset for github")
    
    
    main_path = data_path[0:cut_folder]
    main_path.append(folder)
    main_path.append(file_name)
    main_path = "/".join(main_path)
    Data = pd.read_excel(main_path)
    
    fault_info_path = data_path[0:cut_folder]
    fault_info_path.append(folder)
    fault_info_path.append("Faults_schedule_and_description.xlsx")
    fault_info_path = "/".join(fault_info_path)
    Fault_info = pd.read_excel(fault_info_path, sheet_name="Faults Schedule", usecols="A:B,H")
    Fault_info = Fault_info.drop_duplicates(ignore_index=True)
    
    fault_identifier = []
    for i in range(0, len(Data)):
        for j in range(0, len(Fault_info)):
            if Data["fault"][i] == Fault_info["Name of Fault"][j]:
                fault_identifier.append(Fault_info["Fault identifier"][j])
                break
            if len(Fault_info)-1==j:
                fault_identifier.append(-1)
    Data["Fault_identifier"] = fault_identifier
    
    
    return Data