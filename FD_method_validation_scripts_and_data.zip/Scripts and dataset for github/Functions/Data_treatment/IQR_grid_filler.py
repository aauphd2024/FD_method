# -*- coding: utf-8 -*-
"""
Created on Fri Sep 16 11:49:27 2022

@author: GQ05XY
"""

import scipy.stats as stats
import numpy as np

def IQR_grid_filler(IQR_grid, grid, grid_dim_1_subdivision, grid_dim_2_subdivision,min_points,max_points,IQR_multiplier=1.5):
    """
    Inputs
        IQR_grid:               dictionary, the empty subdivided grid in the form of a dictionary which contains a list for each key
        grid:                   dictionary, the filled out subdivided grid in the form of a dictionary which contains a list for each key
        grid_dim_1_subdivision: integer,    the number of subdivisions for the first dimension (explanatory_variables1)
        grid_dim_2_subdivision: integer,    the number of subdivisions for the second dimension (explanatory_variables2)
        IQR_multiplier:         integer,    the multiplier for calculating the outlier limits
    Outputs
        IQR_grid:               dictionary, the filled out dictionary, containing a list for each key
                                            every key has values corresponding to the 
                                            - lower limit which is Q25 - 1.5*IQR
                                            - Q25 which is the 25th fractile
                                            - Q50 which is the 50th fractile (median)
                                            - Q75 which is the 75th fractile
                                            - upper limit which is the Q75 + 1.5*IQR
                                            - Any following numbers are outliers
    """  
    
    for i in range(1,grid_dim_1_subdivision+1):
        for j in range(1,grid_dim_2_subdivision+1):
            if len(grid[i,j])>=min_points:
                if len(grid[i,j])<max_points:
                    IQR_temporary = stats.iqr(grid[i,j])
                    Q25_temporary = stats.scoreatpercentile(grid[i,j],per=25)
                    Q50_temporary = stats.scoreatpercentile(grid[i,j],per=50)
                    Q75_temporary = stats.scoreatpercentile(grid[i,j],per=75)
                else:
                    IQR_temporary = stats.iqr(grid[i,j][-max_points:])
                    Q25_temporary = stats.scoreatpercentile(grid[i,j][-max_points:],per=25)
                    Q50_temporary = stats.scoreatpercentile(grid[i,j][-max_points:],per=50)
                    Q75_temporary = stats.scoreatpercentile(grid[i,j][-max_points:],per=75)                    
                lower_limit_temporary = Q25_temporary - IQR_multiplier*IQR_temporary
                upper_limit_temporary = Q75_temporary + IQR_multiplier*IQR_temporary
                
                IQR_grid[i,j].append(lower_limit_temporary)
                IQR_grid[i,j].append(Q25_temporary)
                IQR_grid[i,j].append(Q50_temporary)
                IQR_grid[i,j].append(Q75_temporary)
                IQR_grid[i,j].append(upper_limit_temporary)
                
                for k in range(len(grid[i,j])):
                    if grid[i,j][k] < IQR_grid[i,j][0] or grid[i,j][k] > IQR_grid[i,j][4]:
                        IQR_grid[i,j].append(grid[i,j][k])
                
                
            else:
                IQR_grid[i,j].append(np.nan)
                IQR_grid[i,j].append(np.nan)
                IQR_grid[i,j].append(np.nan)
                IQR_grid[i,j].append(np.nan)
                IQR_grid[i,j].append(np.nan)
    return IQR_grid