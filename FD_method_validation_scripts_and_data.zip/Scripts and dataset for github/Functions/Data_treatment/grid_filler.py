# -*- coding: utf-8 -*-
"""
Created on Fri Sep 16 10:36:29 2022

@author: GQ05XY
"""
import math

def grid_filler(main_KPI, explanatory_variables1, explanatory_variables2, grid, grid_dim_1_max, grid_dim_2_max, grid_dim_1_min, grid_dim_2_min, grid_dim_1_subdivision, grid_dim_2_subdivision):
    """
    Inputs
        main_KPI:               series,     the data for the choosen KPI
        explanatory_variables1: series,     the data for the first choosen explanatory variable
        explanatory_variables2: series,     the data for the second choosen explanatory variable
        grid_dim_1_subdivision: integer,    the number of subdivisions for the first dimension (explanatory_variables1)
        grid_dim_2_subdivision: integer,    the number of subdivisions for the second dimension (explanatory_variables2)
        grid:                   dictionary, the subdivided grid in the form of a dictionary which contains a list for each key
        grid_dim_1_max:         float,      the maximum value of the first grid dimension
        grid_dim_2_max:         float,      the maximum value of the second grid dimension
        grid_dim_1_min:         float,      the minimum value of the first grid dimension
        grid_dim_2_min:         float,      the minimum value of the second grid dimension
        grid_dim_1_subdivision: integer,    the number of subdivisions for the first dimension (explanatory_variables1)
        grid_dim_2_subdivision: integer,    the number of subdivisions for the second dimension (explanatory_variables2)
        
    Outputs
        grid:                   dictionary, the filled out dictionary, containing a list for each key
        rejected_datapoints:    integer,    the number representing the amount of bad datapoints, which cannot be placed in the subdivisions (the length of the list in grid position 0,0)
    """    
    
    # append each main_KPI datapoint to its correct location in the grid
    # if the main_KPI or any explanatory variable contains nan, the main_KPI is assigned to grid position 0,0
    for i in range(len(main_KPI)):
        if math.isnan(main_KPI[i]) or math.isnan(explanatory_variables1[i]) or math.isnan(explanatory_variables2[i]):
            grid[0,0].append(main_KPI[i])
        else:
            dim_1_value = grid_dim_1_min
            dim_1_key = 1
            while explanatory_variables1[i] > dim_1_value:
                if dim_1_key == grid_dim_1_subdivision:
                    break
                dim_1_value += (grid_dim_1_max-grid_dim_1_min)/grid_dim_1_subdivision
                dim_1_key += 1
    
            dim_2_value = grid_dim_2_min
            dim_2_key = 1
            while explanatory_variables2[i] > dim_2_value:
                if dim_2_key == grid_dim_2_subdivision:
                    break
                dim_2_value += (grid_dim_2_max-grid_dim_2_min)/grid_dim_2_subdivision
                dim_2_key += 1        
            
    
            grid[dim_1_key,dim_2_key].append(main_KPI[i])
    
    # count the number of rejected datapoints located in grid position 0,0
    rejected_datapoints = len(grid[0,0])
    return grid, rejected_datapoints
