# -*- coding: utf-8 -*-
"""
Created on Fri Sep 16 10:35:36 2022

@author: GQ05XY
"""
import numpy as np
def grid_generator(explanatory_variables1,explanatory_variables2,grid_dim_1_subdivision=10,grid_dim_2_subdivision=10):
    """
    Inputs
        explanatory_variables1: series,     the data for the first choosen explanatory variable
        explanatory_variables2: series,     the data for the second choosen explanatory variable
        grid_dim_1_subdivision: integer,    the number of subdivisions for the first dimension (explanatory_variables1)
        grid_dim_2_subdivision: integer,    the number of subdivisions for the second dimension (explanatory_variables2)
    
    Outputs
        grid:                   dictionary, the subdivided grid in the form of a dictionary which contains a list for each key
        grid_dim_1_max:         float,      the maximum value of the first grid dimension
        grid_dim_2_max:         float,      the maximum value of the second grid dimension
        grid_dim_1_min:         float,      the minimum value of the first grid dimension
        grid_dim_2_min:         float,      the minimum value of the second grid dimension
        grid_dim_1_subdivision: integer,    the number of subdivisions for the first dimension (explanatory_variables1)
        grid_dim_2_subdivision: integer,    the number of subdivisions for the second dimension (explanatory_variables2)
    """
    # calculate the limits of each grid dimension
    grid_dim_1_max = np.nanmax(explanatory_variables1)
    grid_dim_2_max = np.nanmax(explanatory_variables2)
    grid_dim_1_min = np.nanmin(explanatory_variables1)
    grid_dim_2_min = np.nanmin(explanatory_variables2)
    # initiate the main grid
    grid = {}
    # Generate grid dimension 1 and input in the grid dictionary
    for i in range(1,grid_dim_1_subdivision+1):
        temporary = grid_dim_1_min+((grid_dim_1_max-grid_dim_1_min)/grid_dim_1_subdivision)*i
        grid[i,0]=[temporary]
    
    # Generate grid dimension 2 and input in the grid dictionary
    for j in range(1,grid_dim_2_subdivision+1):
        temporary = grid_dim_2_min+((grid_dim_2_max-grid_dim_2_min)/grid_dim_2_subdivision)*j
        grid[0,j]=[temporary]
    
    # Generate all the empty lists in the other grid locations (will be used for holding all the seperated main_KPI datapoints)
    for i in range(1,grid_dim_1_subdivision+1):
        for j in range(1,grid_dim_2_subdivision+1):
            grid[i,j] = []
    grid[0,0]=[]

    return grid, grid_dim_1_max, grid_dim_2_max, grid_dim_1_min, grid_dim_2_min, grid_dim_1_subdivision, grid_dim_2_subdivision
