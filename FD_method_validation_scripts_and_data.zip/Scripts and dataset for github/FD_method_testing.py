# -*- coding: utf-8 -*-
"""
Created on Tue Jul 19 11:04:17 2022

@author: GQ05XY
"""
#Packages needed
import pandas as pd
import os
import time
import datetime
import math
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection, Line3DCollection
from sklearn.neural_network import MLPRegressor
from sklearn.model_selection import train_test_split
from sklearn.model_selection import cross_val_score
from sklearn.decomposition import KernelPCA
from scipy.spatial.distance import mahalanobis
from scipy.stats import chi2
import hdbscan


#Subscripts called
from Functions.Data_import.CTU_UCEEB_dataset_importer import CTU_UCEEB_dataset_importer
from Functions.Data_treatment.grid_generator import grid_generator
from Functions.Data_treatment.grid_filler import grid_filler
from Functions.Data_treatment.IQR_grid_filler import IQR_grid_filler

"#######################################################################################"
"###                                    Data Import                                  ###"
"#######################################################################################"


# Currently available datasets
# If Dataset_type == 2 ; CTU_UCEEB_dataset folder is selected
    # if Dataset_subset == 0 ; AHU1.xlsx is selected
    # if Dataset_subset == 1 ; AHU18.xlsx is selected

Dataset_type = 2
Dataset_subset = 1

# Select how many times the dataset is repeated after itself, 0 = no repeats
Dataset_repeats = 1


if Dataset_type == 2:
    Data = CTU_UCEEB_dataset_importer(Dataset_subset)
    if Dataset_repeats > 0:
        for i in range(Dataset_repeats):
            Data = Data.append(Data)
        Data.reset_index(inplace=True,drop=True)    
    
    fault_data = Data['Fault_identifier']
    if Dataset_subset == 0:
        Title = 'CTU UCEEB dataset AHU1'
    elif Dataset_subset == 1:
        Title = 'CTU UCEEB dataset AHU18'
    
"#######################################################################################"
"###                                    Inputs                                       ###"
"#######################################################################################"

# Steps in the Live FD method (search for '''(modify)''')
# 1  select main KPI
# 2  select explanatory variables
# 3  calculate the current IQR for each grid position where it is possible
# 4  get new datapoint
# 5  check if new datapoint is within expected range
# 6  plot each available boxplot along with the new datapoint, highlight if seen as a potential fault
# 7a give feedback on where potential faults might be if datapoint is outside of expected range
# 7b add datapoint to existing data if datapoint is within expected range
# 8  repeat from step 3
# 9  if component is replaced, add possibility to reset the known datapoints and start from scratch

"#############################################"
"###             Variables                 ###"
"#############################################"
# Variables containing the names of the available measurement points
main_KPI_overview = Data.columns
explanatory_variables_overview = Data.columns

# The time column of the dataset
Data_time = Data[Data.columns[0]]

# Select the KPI and variable set
''' (modify) '''
Data_set = 11


if Dataset_type == 2 and Data_set in [10,11,12]:
    # Define the name of the main KPI and the explanatory variables for the subsets
    ''' (modify) '''    
    if Dataset_subset == 0:
        #AHU1
        main_KPI_name =  Data.columns[14]
        main_KPI_name1 = Data.columns[16]
        explanatory_variables_name1 =  Data.columns[26]
        explanatory_variables_name2 =  Data.columns[5]
        explanatory_variables_name21 = Data.columns[4]
    elif Dataset_subset == 1:
        #AHU18
        main_KPI_name =  Data.columns[2]
        main_KPI_name1 = Data.columns[16]
        explanatory_variables_name1 =  Data.columns[9]
        explanatory_variables_name2 =  Data.columns[3]
        explanatory_variables_name21 = Data.columns[19]
    
    # Define the label for the main KPI and the explanatory variables
    main_KPI_label = 'Room supply and extraction temperature difference'
    explanatory_variables_label1 = 'Supply fan signal'
    explanatory_variables_label2 = 'Heating coil valve signal (in operation)'
    
    # Columns to drop from Data for the full set of features
    ''' (modify) '''
    Data_drops = ['Time',main_KPI_name,main_KPI_name1,'equipment','fault','Fault_identifier']

    # Choose the number of subdivisions for each grid dimension 
    ''' (modify) '''
    if Data_set == 10:
        grid_dim_1_subdivision = 20
        grid_dim_2_subdivision = 20
    elif Data_set == 11:
        grid_dim_1_subdivision = 10
        grid_dim_2_subdivision = 10
    elif Data_set == 12:
        grid_dim_1_subdivision = 5
        grid_dim_2_subdivision = 5         
    

elif Dataset_type == 2 and Data_set in [20,21,22]:
    # Define the name of the main KPI and the explanatory variables 
    ''' (modify) '''
    if Dataset_subset == 0:
        #AHU1
        main_KPI_name =  Data.columns[19]
        main_KPI_name1 = Data.columns[6]
        explanatory_variables_name1 =  Data.columns[21]
        explanatory_variables_name2 =  Data.columns[5]
        explanatory_variables_name21 = Data.columns[23]
    elif Dataset_subset == 1:
        #AHU18    
        main_KPI_name =  Data.columns[13]
        main_KPI_name1 = Data.columns[15]
        explanatory_variables_name1 =  Data.columns[22]
        explanatory_variables_name2 =  Data.columns[3]
        explanatory_variables_name21 = Data.columns[21]
    
    # Define the label for the main KPI and the explanatory variables
    main_KPI_label = 'Heating coil water supply temperature and setpoint difference'
    explanatory_variables_label1 = 'Heating coil on/off signal'
    explanatory_variables_label2 = 'Heating coil valve and pump signal'

    # Columns to drop from Data for the full set of features
    ''' (modify) '''
    Data_drops = ['Time',main_KPI_name,main_KPI_name1,'equipment','fault','Fault_identifier']


    # Choose the number of subdivisions for each grid dimension 
    ''' (modify) '''
    if Data_set == 20:
        grid_dim_1_subdivision = 2
        grid_dim_2_subdivision = 20
    elif Data_set == 21:
        grid_dim_1_subdivision = 2
        grid_dim_2_subdivision = 10
    elif Data_set == 22:
        grid_dim_1_subdivision = 2
        grid_dim_2_subdivision = 5
                


    
elif Dataset_type == 2 and Data_set in [30,31,32]:

    # Define the name of the main KPI and the explanatory variables 
    ''' (modify) '''
    if Dataset_subset == 0:
        #AHU1
        main_KPI_name =  Data.columns[19]
        main_KPI_name1 = Data.columns[6]
        explanatory_variables_name1  = Data.columns[19]
        explanatory_variables_name11 = Data.columns[13]
        explanatory_variables_name2  = Data.columns[5]
        explanatory_variables_name21 = Data.columns[23]
        explanatory_variables_name22 = Data.columns[21]
    elif Dataset_subset == 1:
        #AHU18       
        main_KPI_name =  Data.columns[13]
        main_KPI_name1 = Data.columns[15]
        explanatory_variables_name1  = Data.columns[13]
        explanatory_variables_name11 = Data.columns[14]
        explanatory_variables_name2  = Data.columns[3]
        explanatory_variables_name21 = Data.columns[21]
        explanatory_variables_name22 = Data.columns[22]
    
    # Define the label for the main KPI and the explanatory variables
    main_KPI_label = 'Heating coil water supply temperature and setpoint difference'
    explanatory_variables_label1 = 'Water temperature difference across heating coil'
    explanatory_variables_label2 = 'Heating coil valve, pump signal and on/off signal'

    # Columns to drop from Data for the full set of features
    ''' (modify) '''
    Data_drops = ['Time',main_KPI_name,main_KPI_name1,'equipment','fault','Fault_identifier']



    # Choose the number of subdivisions for each grid dimension 
    ''' (modify) '''
    if Data_set == 30:
        grid_dim_1_subdivision = 20
        grid_dim_2_subdivision = 20
    elif Data_set == 31:
        grid_dim_1_subdivision = 10
        grid_dim_2_subdivision = 10
    elif Data_set == 32:
        grid_dim_1_subdivision = 5
        grid_dim_2_subdivision = 5
        
        

    
"#############################################"
"###    Outliers and fault detection       ###"
"#############################################"
# Chosse the number of outliers to be present in 1 gridpoint for it to be reported 
''' (modify) '''
outlier_bottom_limit = 1

# Choose the multiplier for calculating the outlier limits, as a default, 1.5 is used
''' (modify) '''
IQR_multiplier = 1.5

# Choose the minimum number of points present in a grid before an IQR is calculated 
''' (modify) '''
minimum_points_IQR = 50

# Choose the maximum number of points present in a grid before the forgetting factor starts removing old points 
''' (modify) '''
maximum_points_IQR = 200

# Choose the maximum amount of historical data to consider
# Inserted as number of days
''' (modify) '''
historical_max_time = datetime.timedelta(days=90)

# Insert the time resolution of the data in minutes
''' (modify) '''
data_time_resolution = datetime.timedelta(minutes=5)

### For fault detection method
# Chosse the exponential of the outliers
# If set as 1 the weight will be linear
# If set higher than 1, the deviation of the outlier will exponentially be more (further away points will be punished more)
# Make sure it is never set lower than 1, as the closer outliers will then be more important than further outliers
''' (modify) '''
outlier_weight = 1.5


"#############################################"
"###             MLP input                 ###"
"#############################################"
# Different hidden layer configurations for the MLP
''' (modify) '''
MLP_hidden_layers = [(2,2),(4,4),(6,6),(10,10),(20,20),(40,40),(4,2),(8,4),(12,6),(20,10),(40,20)]

# Set the learning rate for the MLP model
''' (modify) '''
MLP_learning_rate = 0.001

# Set the maximum number of iterations for the MLP model
''' (modify) '''
MLP_max_iter = 2000

# Minimum number of data to be available, to start training the model
''' (modify) '''
MLP_min_points = 1000

# Maximum number of data to be used in the model
''' (modify) '''
MLP_max_points = 10000

# How often the MLP should update its training
''' (modify) '''
MLP_update = 12*24*2

# The extra span for setting the normalization limits of the KPI (set as a multiplier)
''' (modify) '''
MLP_norm_limit_KPI = 0.1

# The extra span for setting the normalization limits of the variables (set as a multiplier)
''' (modify) '''
MLP_norm_limit_variables = 0.1

# The activation function for the MLP
''' (modify) '''
MLP_activation_function = 'relu'

# Empty array for the crossvalidated scores, for choosing the best model parameters
MLP_training_scores = []
MLP1_training_scores = []

# Empty array for removing potential outliers from training sets
MLP_outliers = []
MLP_outliers1 = []





"#############################################"
"###          KPCA modifiers               ###"
"#############################################"

# How often the KPCA should update its training
''' (modify) '''
KPCA_update = 12*24*14

# Minimum number of data to be available, to start training the model
''' (modify) '''
KPCA_min_points = 1000

# Maximum number of data to be used in the model
''' (modify) '''
KPCA_max_points = 10000


# For explanation see https://scikit-learn.org/stable/modules/generated/sklearn.decomposition.KernelPCA.html

# Select the number of components to find
''' (modify) '''
KPCA_n_components = 30

# Select the kernel functions for the KPCA
''' (modify) '''
KPCA_kernel_type = 'rbf'

# Select the number of parralel processes to run
''' (modify) '''
KPCA_n_jobs = 8

# Select if the inverse transform in learned
''' (modify) '''
KPCA_fit_inverse_transform = True

# Select the initial parameter gamma
''' (modify) '''
KPCA_gamma = None

# Select the initial parameter alpha
''' (modify) '''
KPCA_alpha = 1

# Select the limit for how much variance should be explained by the principal components
''' (modify) '''
KPCA_variance_limit = 0.85


"#############################################"
"###          HDBscan modifiers            ###"
"#############################################"

# How often the KPCA should update its training
''' (modify) '''
HDBscan_update = 12*24

# Minimum number of data to be available, to start training the model
''' (modify) '''
HDBscan_min_points = 1000

# Maximum number of data to be used in the model
''' (modify) '''
HDBscan_max_points = 100000

# Minimum number of points in a cluster
''' (modify) '''
HDBscan_min_cluster_points = 50


# Minimum number of data to be available, to start training the model if seperated in grids
''' (modify) '''
HDBscan_grid_min_points = 100

# Maximum number of data to be used in the model
''' (modify) '''
HDBscan_grid_max_points = 100000

# Minimum number of points in a cluster
''' (modify) '''
HDBscan_grid_min_cluster_points = 20

# setup empty dict for the HDBscan to check when the model for the individual grids were last updated
HDBscan_grid_update = {}
# setup empty dict for the HDBscan to check when the model for the individual grids were last updated
HDBscan_grid_model = {}


"#############################################"
"###          Fault thresholds             ###"
"#############################################"
# Set the thresholds for defining the occurence of a fault
# The numbers included are the specific results indicating faults

Fault_1_threshold = [-5, 5]
Fault_2_threshold = [-5, 5]
Fault_3_threshold = [-5, 5]
Fault_4_threshold = [5]
Fault_5_threshold = [5]
Fault_6_threshold = []
Fault_7_threshold = [4, 5]
Fault_8_threshold = [-1, 4]
Fault_9_threshold = [-1, 4]
Fault_10_threshold = [-5, 5]


"#############################################"
"###          Plotting and saving plots    ###"
"#############################################"
# Choose if any plots should be made
''' (modify) '''
run_plot = 1


# Choose how often the plot should be updated 
''' (modify) '''
run_plot_number = 12

# Set if good performance for the main KPI is high, low or middle 
''' (modify) '''
GP = 'middle'
# if GP is middle, fill out the point which should be green
GP_middle_point = 0

# Choose how many previous points should be shown in the fault indicator plot 
''' (modify) '''
FD_plot_number_of_points = 12*24

# Choose if plot 3 shows the final fault result or the risk of fault.
# If 'risk' the risk value is plotted
# If 'fault' either 0= no fault or 1= fault is plotted
''' (modify) '''
plot_3_type = 'fault'

# Display plots?
# if 0, plots are not displayed
# if 1, plot are displayed
''' (modify) '''
plot_display = 1

# Save plots?
# if 0, plots are not saved
# if 1, plot are saved
''' (modify) '''
plot_save = 1

# Set the name of the folder to save the plots to
# input the path below the folder of the __main__.py script
''' (modify) '''
save_folder_name = 'Test_images'

save_folder = save_folder_name+'_'+str(Dataset_type)+'_'+str(Dataset_subset)+'_'+str(Data_set)



# Adjustment parameters for the plot of the data
plot_main_KPI_multiplier = 1
plot_explanatory_variable_multiplier1 = 1
plot_explanatory_variable_multiplier2 = 1

"#############################################"
"###          Other                        ###"
"#############################################"
# Choose if the timing of the different parts should be printed
''' (modify) '''
see_time = 1

#Set the starting point to run from
''' (modify) '''
starting_point = 39900

# Set the end point to run until
''' (modify) '''
end_point = 40000 #len(Data)

"#######################################################################################"
"###                         Calculation of results                                  ###"
"#######################################################################################"
# Logical error checker
assert outlier_weight >= 1, "Make sure the outlier weight is at least 1, otherwise further outliers are less important than close outliers"



# Control for which fault detection methods to run
# if True it is run, if False it is not run
Fault_1_method_run = True
Fault_2_method_run = True
Fault_3_method_run = True
Fault_4_method_run = True
Fault_5_method_run = True
Fault_6_method_run = True
Fault_7_method_run = True
Fault_8_method_run = True
Fault_9_method_run = True
Fault_10_method_run = True


# Empty lists for the risk of fault using the different methods
Fault_1_risk = []
Fault_2_risk = []
Fault_3_risk = []
Fault_4_risk = []
Fault_5_risk = []
Fault_6_risk = []
Fault_7_risk = []
Fault_8_risk = []
Fault_9_risk = []
Fault_10_risk = []
Fault_1_risk_detected = []
Fault_2_risk_detected = []
Fault_3_risk_detected = []
Fault_4_risk_detected = []
Fault_5_risk_detected = []
Fault_6_risk_detected = []
Fault_7_risk_detected = []
Fault_8_risk_detected = []
Fault_9_risk_detected = []
Fault_10_risk_detected = []
Fault_1_risk_time = []
Fault_2_risk_time = []
Fault_3_risk_time = []
Fault_4_risk_time = []
Fault_5_risk_time = []
Fault_6_risk_time = []
Fault_7_risk_time = []
Fault_8_risk_time = []
Fault_9_risk_time = []
Fault_10_risk_time = []
Fault_1_faulty = []
Fault_2_faulty = []
Fault_3_faulty = []
Fault_4_faulty = []
Fault_5_faulty = []
Fault_6_faulty = []
Fault_7_faulty = []
Fault_8_faulty = []
Fault_9_faulty = []
Fault_10_faulty = []


tstart = time.time()

"#######################################################################################"
"###                         Functions                                               ###"
"#######################################################################################"

def MLP_normalizer_series(MLP_data,limiter):
    """
    Purpose
    Convert a series from normal form to normalized form
    
    Inputs
    MLP_data is the list, Series or DataFrame containing data for the MLP
    limiter is the float containing the multipler for the limits of the normalization
    
    Outputs
    MLP_data_norm is the same format as MLP_data containing the normalized data for the MLP, with expanded limits according to the limiter
    MLP_data_min is the minimum limit used for normalization
    MLP_data_max is the maximum limit used for normalization
    """
    if type(MLP_data)==list:
        if min(MLP_data) > 0:
            limit_mod_min = -1
        else:
            limit_mod_min = 1
        if max(MLP_data) > 0:
            limit_mod_max = 1
        else:
            limit_mod_max = -1  
        MLP_data_min = min(MLP_data)+min(MLP_data)*limiter*limit_mod_min
        MLP_data_max = max(MLP_data)+max(MLP_data)*limiter*limit_mod_max
        MLP_data_norm = [(x-MLP_data_min)/(MLP_data_max-MLP_data_min) for x in MLP_data]
    elif isinstance(MLP_data, pd.Series):
        if MLP_data.min() > 0:
            limit_mod_min = -1
        else:
            limit_mod_min = 1
        if MLP_data.max() > 0:
            limit_mod_max = 1
        else:
            limit_mod_max = -1
        MLP_data_min = MLP_data.min()+MLP_data.min()*limiter*limit_mod_min
        MLP_data_max = MLP_data.max()+MLP_data.max()*limiter*limit_mod_max      
        MLP_data_norm = (MLP_data-MLP_data_min)/(MLP_data_max-MLP_data_min)
    elif isinstance(MLP_data, pd.DataFrame):
        MLP_data_min = []
        MLP_data_max = []
        MLP_data_norm = pd.DataFrame()
        for column_name in MLP_data.columns:
            if MLP_data[column_name].min() > 0:
                limit_mod_min = -1
            else:
                limit_mod_min = 1
            if MLP_data[column_name].max() > 0:
                limit_mod_max = 1
            else:
                limit_mod_max = -1
            MLP_data_min_temp = MLP_data[column_name].min()+MLP_data[column_name].min()*limiter*limit_mod_min
            MLP_data_min.append(MLP_data_min_temp)
            MLP_data_max_temp = MLP_data[column_name].max()+MLP_data[column_name].max()*limiter*limit_mod_max
            MLP_data_max.append(MLP_data_max_temp)
            MLP_data_norm[column_name] = (MLP_data[column_name]-MLP_data_min_temp)/(MLP_data_max_temp-MLP_data_min_temp)
                
    return MLP_data_norm, MLP_data_min, MLP_data_max
                
def MLP_normalizer_point(Data,limit_min,limit_max,switch):
    """
    Purpose
    Either convert a datapoint to normalized form or convert it back to normal form
    
    Inputs
    Data is the floating value for the datapoint to normalize or renormalize
    limit_min is the bottom limit used for normalizing the full dataset
    limit_max is the upper limit used for normalizing the full dataset
    switch is the integer input for determining if the conversion is from normal to normalized form or reverse
    
    Outputs
    Data_norm is the normalized value
    Data is the renormalized value
    """
    if switch == 0:
        Data_norm = (Data-limit_min)/(limit_max-limit_min)
        return Data_norm
    elif switch ==1:
        Data = Data*(limit_max-limit_min)+limit_min
        return Data
     
def KPCA_mahalanobis_vars(array):
    covariance = np.cov(array , rowvar=False)
    inverse_covariance = np.linalg.matrix_power(covariance, -1)

    mean = np.mean(array, axis=0)
    
    return mean, inverse_covariance

"#######################################################################################"
"###                         Solver                                                  ###"
"#######################################################################################"

historical_time_limit = historical_max_time/data_time_resolution





for run in range(starting_point,end_point):
    t0 = time.time()
    
    historical_time_start = int(run-historical_time_limit)
    if historical_time_start < 0:
        historical_time_start = 0
    
    
    
    "#############################################"
    "###          Initiation                   ###"
    "#############################################"
    # Define the calculation of the main KPI for the current step
    
    if Data_set == 10 or Data_set == 11 or Data_set == 12:
        # if it is just taken directly from Data, use this formulation 
        # Data[main_KPI_name][:run]
        ''' (modify) '''
        main_KPI = [element1 - element2 for (element1, element2) in zip(Data[main_KPI_name][historical_time_start:run], Data[main_KPI_name1][historical_time_start:run])]
        
        # Define the calculation of explanatory variable 1 for the current step
        # if it is just taken directly from Data, use this formulation 
        # Data[explanatory_variables_name1][:run]
        ''' (modify) '''
        explanatory_variables1 = Data[explanatory_variables_name1][historical_time_start:run]
        explanatory_variables1.reset_index(inplace=True,drop=True)
        
        # Define the calculation of explanatory variable 2 for the current step
        # if it is just taken directly from Data, use this formulation 
        # Data[explanatory_variables_name2][:run]
        ''' (modify) '''
        explanatory_variables2 = [element1 * element2 for (element1, element2) in zip(Data[explanatory_variables_name2][historical_time_start:run],Data[explanatory_variables_name21][historical_time_start:run])]
        explanatory_variables2 = pd.Series(explanatory_variables2)
        explanatory_variables2.reset_index(inplace=True,drop=True)
        
        # Import all variables expect for those used for the main_KPI
        explanatory_variables_all = Data[:][historical_time_start:run].copy()
        explanatory_variables_all.drop(Data_drops,axis=1,inplace=True)
        explanatory_variables_all.reset_index(inplace=True,drop=True)
    
    
    elif Data_set == 20 or Data_set == 21 or Data_set == 22:
        # if it is just taken directly from Data, use this formulation 
        # Data[main_KPI_name][:run]       ''' (modify) '''
        main_KPI = [element1 - element2 for (element1, element2) in zip(Data[main_KPI_name][historical_time_start:run], Data[main_KPI_name1][historical_time_start:run])]
        
        # Define the calculation of explanatory variable 1 for the current step
        # if it is just taken directly from Data, use this formulation 
        # Data[explanatory_variables_name1][:run]
        ''' (modify) '''
        explanatory_variables1 = Data[explanatory_variables_name1][historical_time_start:run]
        explanatory_variables1.reset_index(inplace=True,drop=True)
        
        # Define the calculation of explanatory variable 2 for the current step
        # if it is just taken directly from Data, use this formulation 
        # Data[explanatory_variables_name2][:run]
        ''' (modify) '''
        explanatory_variables2 = [element1 * element2 for (element1, element2) in zip(Data[explanatory_variables_name2][historical_time_start:run],Data[explanatory_variables_name21][historical_time_start:run])]
        explanatory_variables2 = pd.Series(explanatory_variables2)
        explanatory_variables2.reset_index(inplace=True,drop=True)
        
        # Import all variables expect for those used for the main_KPI
        explanatory_variables_all = Data[:][historical_time_start:run].copy()
        explanatory_variables_all.drop(Data_drops,axis=1,inplace=True)
        explanatory_variables_all.reset_index(inplace=True,drop=True)

    
    elif Data_set == 30 or Data_set == 31 or Data_set == 32:
        # if it is just taken directly from Data, use this formulation 
        # Data[main_KPI_name][:run]
        ''' (modify) '''
        main_KPI = [element1 - element2 for (element1, element2) in zip(Data[main_KPI_name][historical_time_start:run], Data[main_KPI_name1][historical_time_start:run])]
        
        # Define the calculation of explanatory variable 1 for the current step
        # if it is just taken directly from Data, use this formulation 
        # Data[explanatory_variables_name1][:run]
        ''' (modify) '''
        explanatory_variables1 = [element1 - element2 for (element1, element2) in zip(Data[explanatory_variables_name1][historical_time_start:run],Data[explanatory_variables_name11][historical_time_start:run])]
        explanatory_variables1 = pd.Series(explanatory_variables1)
        explanatory_variables1.reset_index(inplace=True,drop=True)
        
        # Define the calculation of explanatory variable 2 for the current step
        # if it is just taken directly from Data, use this formulation 
        # Data[explanatory_variables_name2][:run]
        ''' (modify) '''
        explanatory_variables2 = [element1 * element2 * element3 for (element1, element2, element3) in zip(Data[explanatory_variables_name2][historical_time_start:run],Data[explanatory_variables_name21][historical_time_start:run],Data[explanatory_variables_name22][historical_time_start:run])]
        explanatory_variables2 = pd.Series(explanatory_variables2)
        explanatory_variables2.reset_index(inplace=True,drop=True)
        
        # Import all variables expect for those used for the main_KPI
        explanatory_variables_all = Data[:][historical_time_start:run].copy()
        explanatory_variables_all.drop(Data_drops,axis=1,inplace=True)
        explanatory_variables_all.reset_index(inplace=True,drop=True)




    "#############################################"
    "###          Grid generator               ###"
    "#############################################" 
    # Sets current fault status as the one from the dataset
    # is defined in the Data import
    fault_status = fault_data[historical_time_start:run]
    
    # Creates the empty subdivided grid
    grid, grid_dim_1_max, grid_dim_2_max, grid_dim_1_min, grid_dim_2_min, grid_dim_1_subdivision, grid_dim_2_subdivision = grid_generator(explanatory_variables1,explanatory_variables2,grid_dim_1_subdivision,grid_dim_2_subdivision)
    
    # Adds the datapoints to their subdivided location
    grid, rejected_datapoints = grid_filler(main_KPI, explanatory_variables1, explanatory_variables2, grid, grid_dim_1_max, grid_dim_2_max, grid_dim_1_min, grid_dim_2_min, grid_dim_1_subdivision, grid_dim_2_subdivision)
    
    # Generate an empty subdivided grid for the IQR calculations
    IQR_grid = grid_generator(explanatory_variables1,explanatory_variables2,grid_dim_1_subdivision,grid_dim_2_subdivision)[0]
    
    # Calculate the boxplot values for each of the subdivided areas
    IQR_grid = IQR_grid_filler(IQR_grid, grid, grid_dim_1_subdivision, grid_dim_2_subdivision,minimum_points_IQR,maximum_points_IQR,IQR_multiplier)
    
    # Calculate the step size for each grid
    grid_dim_1_step = ((grid_dim_1_max-grid_dim_1_min)/grid_dim_1_subdivision)
    grid_dim_2_step = ((grid_dim_2_max-grid_dim_2_min)/grid_dim_2_subdivision)
            
    t1 = time.time()
    
    
    "#######################################################"
    "###          Fault detection method 1               ###"
    "### Simple MLP based on the explanatory variables   ###"
    "### with IQR for asessing faulty state              ###"
    "#######################################################"
    # Calculation for the probability of a fault
    MLP_outliers.append(['run',run])
    if MLP_min_points < len(main_KPI) and Fault_1_method_run:
        try:
            if run%MLP_update == 0 or MLP_min_points+1 == len(main_KPI):
                # Initialize the newest data for the main KPI and explanatory variables and remove the current point
                main_KPI_MLP = main_KPI.copy()
                main_KPI_MLP.pop()
                if run > MLP_max_points:
                    main_KPI_MLP = main_KPI_MLP[-MLP_max_points:]
                
                explanatory_variables1_MLP = explanatory_variables1.copy()
                explanatory_variables1_MLP.drop(explanatory_variables1_MLP.tail(1).index, inplace=True)
                if run > MLP_max_points:
                    explanatory_variables1_MLP.drop(explanatory_variables1_MLP.head(len(explanatory_variables1_MLP)-MLP_max_points).index, inplace=True)
                
                explanatory_variables2_MLP = explanatory_variables2.copy()
                explanatory_variables2_MLP.drop(explanatory_variables2_MLP.tail(1).index, inplace=True)
                if run > MLP_max_points:
                    explanatory_variables2_MLP.drop(explanatory_variables2_MLP.head(len(explanatory_variables2_MLP)-MLP_max_points).index, inplace=True)
                
                index_remover_MLP = []
                
                # Remove all nan samples before training
                for x in range(len(main_KPI_MLP)):
                    if math.isnan(explanatory_variables1_MLP[x]) or math.isnan(explanatory_variables2_MLP[x]) or math.isnan(main_KPI_MLP[x]):
                        index_remover_MLP.append(x)
                index_remover_MLP.reverse()
                for x in range(len(index_remover_MLP)):
                    main_KPI_MLP.pop(index_remover_MLP[x])
                    explanatory_variables1_MLP.pop(index_remover_MLP[x])
                    explanatory_variables2_MLP.pop(index_remover_MLP[x])
                
                # Normalize the features
                main_KPI_MLP_norm,main_KPI_MLP_norm_limit_min,main_KPI_MLP_norm_limit_max = MLP_normalizer_series(main_KPI_MLP,MLP_norm_limit_KPI)
                explanatory_variables1_MLP_norm,explanatory_variables1_MLP_norm_limit_min,explanatory_variables1_MLP_norm_limit_max = MLP_normalizer_series(explanatory_variables1_MLP,MLP_norm_limit_variables)
                explanatory_variables2_MLP_norm,explanatory_variables2_MLP_norm_limit_min,explanatory_variables2_MLP_norm_limit_max = MLP_normalizer_series(explanatory_variables2_MLP,MLP_norm_limit_variables)
                
                
                # MLP training and prediction ###
                MLP_X = pd.DataFrame()
                MLP_X['explanatory_variables1'] = explanatory_variables1_MLP_norm
                MLP_X['explanatory_variables2'] = explanatory_variables2_MLP_norm
                MLP_y = main_KPI_MLP_norm   
                MLP_scores = []
                
                
                # Run a test to find the best performing hyper parameters
                MLP_X_train, MLP_X_test, MLP_y_train, MLP_y_test = train_test_split(MLP_X, MLP_y)
                for i in range(len(MLP_hidden_layers)):
                    MLP_regr = MLPRegressor(MLP_hidden_layers[i],activation=MLP_activation_function,learning_rate_init=MLP_learning_rate, max_iter=MLP_max_iter).fit(MLP_X_train.values.reshape(-1,len(MLP_X.columns)), MLP_y_train)
                    MLP_score = cross_val_score(MLP_regr,MLP_X_train,MLP_y_train,cv=10,scoring='neg_mean_absolute_error').mean()
                    MLP_scores.append(MLP_score)
                MLP_training_scores.append(max(MLP_scores))    
                # Create the training and testing dataset and fit the model

                MLP_regr = MLPRegressor(MLP_hidden_layers[MLP_scores.index(max(MLP_scores))],activation=MLP_activation_function,learning_rate_init=MLP_learning_rate, max_iter=MLP_max_iter).fit(MLP_X_train.values.reshape(-1,len(MLP_X.columns)), MLP_y_train)    
            
            # Normalize the data for the current point
            current_explanatory_variables1_MLP = MLP_normalizer_point(float(explanatory_variables1[-1:]),explanatory_variables1_MLP_norm_limit_min,explanatory_variables1_MLP_norm_limit_max,0)
            current_explanatory_variables2_MLP = MLP_normalizer_point(float(explanatory_variables2[-1:]),explanatory_variables2_MLP_norm_limit_min,explanatory_variables2_MLP_norm_limit_max,0)
            
            # Run the prediction on the current datapoint
            MLP_prediction = MLP_regr.predict(np.array([current_explanatory_variables1_MLP,current_explanatory_variables2_MLP]).reshape(-1,2))     
            MLP_prediction = MLP_normalizer_point(MLP_prediction,main_KPI_MLP_norm_limit_min,main_KPI_MLP_norm_limit_max,1)
            
            MLP_outliers.append(['Prediction',MLP_prediction])
            

            
            
            # Find which subdivision the current datapoint is in
            for i in range(1,grid_dim_1_subdivision+1):
                if i == 1:
                    cond1 = explanatory_variables1[len(explanatory_variables1)-1] >= grid[i,0]-grid_dim_1_step
                else:
                    cond1 = explanatory_variables1[len(explanatory_variables1)-1] > grid[i,0]-grid_dim_1_step
                cond2 = explanatory_variables1[len(explanatory_variables1)-1] <= grid[i,0]
                if cond1[0] and cond2[0]:
                    MLP_outliers.append(['Cond12','exists'])
                    for j in range(1,grid_dim_2_subdivision+1):
                        if j == 1:
                            cond3 = explanatory_variables2[len(explanatory_variables2)-1] >= grid[0,j]-grid_dim_2_step
                        else:
                            cond3 = explanatory_variables2[len(explanatory_variables2)-1] > grid[0,j]-grid_dim_2_step
                        cond4 = explanatory_variables2[len(explanatory_variables2)-1] <= grid[0,j]
                        if cond3[0] and cond4[0]:
                            MLP_outliers.append(['Cond34','exists'])
                            # Calculate the length between the median and the low limit and high limit
                            low_limit = IQR_grid[i,j][2]-IQR_grid[i,j][0]
                            high_limit = IQR_grid[i,j][4]-IQR_grid[i,j][2]
                            # Calculate the IQR
                            IQR = (IQR_grid[i,j][3]-IQR_grid[i,j][1])*IQR_multiplier
                            # Check if the prediction is within the expected limits
                            if main_KPI[-1] > MLP_prediction + IQR*4 + high_limit:
                                Fault_1_risk.append(5)
                                MLP_outliers.append(['Fault_risk',5])
                                Fault_1_risk_time.append(run)

                            elif main_KPI[-1] > MLP_prediction + IQR*3 + high_limit:
                                Fault_1_risk.append(4)
                                MLP_outliers.append(['Fault_risk',4])
                                Fault_1_risk_time.append(run)

                            elif main_KPI[-1] > MLP_prediction + IQR*2 + high_limit:
                                Fault_1_risk.append(3)
                                MLP_outliers.append(['Fault_risk',3])
                                Fault_1_risk_time.append(run)

                            elif main_KPI[-1] > MLP_prediction + IQR + high_limit:
                                Fault_1_risk.append(2)
                                MLP_outliers.append(['Fault_risk',2])
                                Fault_1_risk_time.append(run)

                            elif main_KPI[-1] > MLP_prediction + IQR:
                                Fault_1_risk.append(1)
                                MLP_outliers.append(['Fault_risk',1])
                                Fault_1_risk_time.append(run)

                            elif main_KPI[-1] < MLP_prediction - IQR*4 - low_limit:
                                Fault_1_risk.append(-5)
                                MLP_outliers.append(['Fault_risk',-5])
                                Fault_1_risk_time.append(run)

                            elif main_KPI[-1] < MLP_prediction - IQR*3 - low_limit:
                                Fault_1_risk.append(-4)
                                MLP_outliers.append(['Fault_risk',-4])
                                Fault_1_risk_time.append(run)

                            elif main_KPI[-1] < MLP_prediction - IQR*2 - low_limit:
                                Fault_1_risk.append(-3)
                                MLP_outliers.append(['Fault_risk',-3])
                                Fault_1_risk_time.append(run)

                            elif main_KPI[-1] < MLP_prediction - IQR - low_limit:
                                Fault_1_risk.append(-2)
                                MLP_outliers.append(['Fault_risk',-2])
                                Fault_1_risk_time.append(run)

                            elif main_KPI[-1] < MLP_prediction - IQR:
                                Fault_1_risk.append(-1)    
                                MLP_outliers.append(['Fault_risk',-1])
                                Fault_1_risk_time.append(run)

                            else:
                                Fault_1_risk.append(0)  
                                MLP_outliers.append(['Fault_risk',0])
                                Fault_1_risk_time.append(run)


            

        except:
            Fault_1_risk.append(0)  
            MLP_outliers.append(['Error'])
            Fault_1_risk_time.append(run)
    else:
        Fault_1_risk.append(0) 
        MLP_outliers.append(['Low number of points'])
        Fault_1_risk_time.append(run)
    
    if Fault_1_risk_time[-1] != run:
        Fault_1_risk.append(0)  
        MLP_outliers.append(['Missing run'])
        Fault_1_risk_time.append(run)
        
    if Fault_1_method_run:
        if Fault_1_risk[-1] in Fault_1_threshold:
            Fault_1_faulty.append(1)
        else:
            Fault_1_faulty.append(0)
    
    t2 = time.time()            
                
    "#############################################"
    "###          Fault detection method 2     ###"
    "###         Newest point outlier check    ###"
    "#############################################"           
    # Calculation for the probability of a fault
    Fault_2 = 0
    if Fault_2_method_run:
        try:
            for i in range(1,grid_dim_1_subdivision+1):
                if i == 1:
                    cond1 = explanatory_variables1[len(explanatory_variables1)-1] >= grid[i,0]-grid_dim_1_step
                else:
                    cond1 = explanatory_variables1[len(explanatory_variables1)-1] > grid[i,0]-grid_dim_1_step
                cond2 = explanatory_variables1[len(explanatory_variables1)-1] <= grid[i,0]
                if cond1[0] and cond2[0]:
                    for j in range(1,grid_dim_2_subdivision+1):
                        if j == 1:
                            cond3 = explanatory_variables2[len(explanatory_variables2)-1] >= grid[0,j]-grid_dim_2_step
                        else:
                            cond3 = explanatory_variables2[len(explanatory_variables2)-1] > grid[0,j]-grid_dim_2_step
                        cond4 = explanatory_variables2[len(explanatory_variables2)-1] <= grid[0,j]
                        if cond3[0] and cond4[0]:
                            low_limit = IQR_grid[i,j][0]
                            high_limit = IQR_grid[i,j][4]
                            IQR = (IQR_grid[i,j][3]-IQR_grid[i,j][1])*IQR_multiplier                    
                            if main_KPI[-1] < low_limit - IQR*4:
                                Fault_2 = -5
                            elif main_KPI[-1] < low_limit - IQR*3:
                                Fault_2 = -4
                            elif main_KPI[-1] < low_limit - IQR*2:
                                Fault_2 = -3
                            elif main_KPI[-1] < low_limit - IQR:
                                Fault_2 = -2
                            elif main_KPI[-1] < low_limit:
                                Fault_2 = -1
                            elif main_KPI[-1] > high_limit + IQR*4:
                                Fault_2 = 5
                            elif main_KPI[-1] > high_limit + IQR*3:
                                Fault_2 = 4
                            elif main_KPI[-1] > high_limit + IQR*2:
                                Fault_2 = 3
                            elif main_KPI[-1] > high_limit + IQR:
                                Fault_2 = 2
                            elif main_KPI[-1] > high_limit:
                                Fault_2 = 1
                            else:
                                Fault_2 = 0
                                
                            Fault_2_risk.append(Fault_2)
                            Fault_2_risk_time.append(run)
                            Fault_2_risk_detected = Fault_2
                            Fault_2 = 10
                            break
            if Fault_2 == 0:
                Fault_2_risk.append(0)
                Fault_2_risk_time.append(run)
                Fault_2_risk_detected = 0
        except:
            Fault_2_risk.append(0)
            Fault_2_risk_time.append(run)
            Fault_2_risk_detected = 0

    
    if Fault_2_method_run:
        if Fault_2_risk[-1] in Fault_2_threshold:
            Fault_2_faulty.append(1)
        else:
            Fault_2_faulty.append(0)


    t3 = time.time()
    "############################################################"
    "###          Fault detection method 3                    ###"
    "### Advanced MLP based on all features in data           ###"
    "### with IQR for asessing faulty state                   ###"
    "############################################################"
    # Calculation for the probability of a fault
    MLP_outliers1.append(['run',run])
    if MLP_min_points < len(main_KPI) and Fault_3_method_run:
        try:
            if run%MLP_update == 0 or MLP_min_points+1 == len(main_KPI):
                # Initialize the newest data for the main KPI and explanatory variables and remove the current point
                main_KPI_MLP1 = main_KPI.copy()
                main_KPI_MLP1.pop()
                if run > MLP_max_points:
                    main_KPI_MLP1 = main_KPI_MLP1[-MLP_max_points:]
                
                explanatory_variables_all_MLP1 = explanatory_variables_all.copy()
                explanatory_variables_all_MLP1.drop(explanatory_variables_all_MLP1.tail(1).index, inplace=True)
                if run > MLP_max_points:
                    explanatory_variables_all_MLP1.drop(explanatory_variables_all_MLP1.head(len(explanatory_variables_all_MLP1)-MLP_max_points).index, inplace=True)
                explanatory_variables_all_MLP1.reset_index(inplace=True, drop=True)
                
                index_remover_MLP1 = []
                
                # Remove all nan samples before training
                for x in range(len(main_KPI_MLP1)):
                    if explanatory_variables_all_MLP1.isna().any(axis=1)[x] or math.isnan(main_KPI_MLP1[x]):
                        index_remover_MLP1.append(x)
                index_remover_MLP1.reverse()
                for x in range(len(index_remover_MLP1)):
                    main_KPI_MLP1.pop(index_remover_MLP1[x])
                explanatory_variables_all_MLP1.drop(index_remover_MLP1,axis=0,inplace=True)
                
                # Remove all no-change columns before training
                for column in explanatory_variables_all_MLP1.columns:
                    if explanatory_variables_all_MLP1[column].min() == explanatory_variables_all_MLP1[column].max():
                        explanatory_variables_all_MLP1.drop(columns=column,inplace=True)
                
                # Normalize the features
                main_KPI_MLP1_norm,main_KPI_MLP1_norm_limit_min,main_KPI_MLP1_norm_limit_max = MLP_normalizer_series(main_KPI_MLP1,MLP_norm_limit_KPI)
                explanatory_variables_all_MLP1_norm,explanatory_variables_all_MLP1_norm_limit_min,explanatory_variables_all_MLP1_norm_limit_max = MLP_normalizer_series(explanatory_variables_all_MLP1,MLP_norm_limit_variables)
                
                
                # MLP training and prediction ###
                MLP1_scores = []
                MLP1_X = explanatory_variables_all_MLP1_norm
                MLP1_y = main_KPI_MLP1_norm   
            
                # Run a test to find the best performing training dataset split
                MLP1_X_train, MLP1_X_test, MLP1_y_train, MLP1_y_test = train_test_split(MLP1_X, MLP1_y)
                for i in range(len(MLP_hidden_layers)):
                    MLP1_regr = MLPRegressor(MLP_hidden_layers[i],activation=MLP_activation_function,learning_rate_init=MLP_learning_rate, max_iter=MLP_max_iter).fit(MLP1_X_train.values.reshape(-1,len(MLP1_X.columns)), MLP1_y_train)
                    MLP1_score = cross_val_score(MLP1_regr,MLP1_X_train,MLP1_y_train,cv=10,scoring='neg_mean_absolute_error').mean()
                    MLP1_scores.append(MLP1_score)
                MLP1_training_scores.append(max(MLP1_scores))   
                # Create the training and testing dataset and fit the model

                MLP1_regr = MLPRegressor(MLP_hidden_layers[MLP1_scores.index(max(MLP1_scores))],activation=MLP_activation_function,learning_rate_init=MLP_learning_rate, max_iter=MLP_max_iter).fit(MLP1_X_train.values.reshape(-1,len(MLP1_X.columns)), MLP1_y_train)
            
            # Normalize the data for the current point
            current_explanatory_variables_all_MLP1_temp = []
            for x in range(len(explanatory_variables_all_MLP1.columns)):
                current_explanatory_variables_all_MLP1_temp.append(MLP_normalizer_point(float(explanatory_variables_all[explanatory_variables_all.columns[x]][-1:]),explanatory_variables_all_MLP1_norm_limit_min[x],explanatory_variables_all_MLP1_norm_limit_max[x],0))
            current_explanatory_variables_all_MLP1 = pd.DataFrame([current_explanatory_variables_all_MLP1_temp])
            
            # Run the prediction on the current datapoint
            MLP1_prediction = MLP1_regr.predict(np.array(current_explanatory_variables_all_MLP1[:][-1:]).reshape(-1,len(current_explanatory_variables_all_MLP1.columns)))  
            MLP1_prediction = MLP_normalizer_point(MLP1_prediction,main_KPI_MLP1_norm_limit_min,main_KPI_MLP1_norm_limit_max,1)
            
            MLP_outliers1.append(['Prediction',MLP1_prediction])

            
            
            # Find which subdivision the current datapoint is in
            for i in range(1,grid_dim_1_subdivision+1):
                if i == 1:
                    cond1 = explanatory_variables1[len(explanatory_variables1)-1] >= grid[i,0]-grid_dim_1_step
                else:
                    cond1 = explanatory_variables1[len(explanatory_variables1)-1] > grid[i,0]-grid_dim_1_step
                cond2 = explanatory_variables1[len(explanatory_variables1)-1] <= grid[i,0]
                if cond1[0] and cond2[0]:
                    MLP_outliers1.append(['Cond12','exists'])
                    for j in range(1,grid_dim_2_subdivision+1):
                        if j == 1:
                            cond3 = explanatory_variables2[len(explanatory_variables2)-1] >= grid[0,j]-grid_dim_2_step
                        else:
                            cond3 = explanatory_variables2[len(explanatory_variables2)-1] > grid[0,j]-grid_dim_2_step
                        cond4 = explanatory_variables2[len(explanatory_variables2)-1] <= grid[0,j]
                        if cond3[0] and cond4[0]:
                            MLP_outliers1.append(['Cond34','exists'])
                            # Calculate the length between the median and the low limit and high limit
                            low_limit = IQR_grid[i,j][2]-IQR_grid[i,j][0]
                            high_limit = IQR_grid[i,j][4]-IQR_grid[i,j][2]
                            # Calculate the IQR
                            IQR = (IQR_grid[i,j][3]-IQR_grid[i,j][1])*IQR_multiplier
                            # Check if the prediction is within the expected limits
                            if main_KPI[-1] > MLP1_prediction + IQR*4 + high_limit:
                                Fault_3_risk.append(5)
                                MLP_outliers1.append(['Fault_risk',5])
                                Fault_3_risk_time.append(run)
                            elif main_KPI[-1] > MLP1_prediction + IQR*3 + high_limit:
                                Fault_3_risk.append(4)
                                MLP_outliers1.append(['Fault_risk',4])
                                Fault_3_risk_time.append(run)
                            elif main_KPI[-1] > MLP1_prediction + IQR*2 + high_limit:
                                Fault_3_risk.append(3)
                                MLP_outliers1.append(['Fault_risk',3])   
                                Fault_3_risk_time.append(run)
                            elif main_KPI[-1] > MLP1_prediction + IQR + high_limit:
                                Fault_3_risk.append(2)
                                MLP_outliers1.append(['Fault_risk',2])  
                                Fault_3_risk_time.append(run)
                            elif main_KPI[-1] > MLP1_prediction + IQR:
                                Fault_3_risk.append(1)
                                MLP_outliers1.append(['Fault_risk',1])
                                Fault_3_risk_time.append(run)
                            elif main_KPI[-1] < MLP1_prediction - IQR*4 - low_limit:
                                Fault_3_risk.append(-5)
                                MLP_outliers1.append(['Fault_risk',-5])
                                Fault_3_risk_time.append(run)
                            elif main_KPI[-1] < MLP1_prediction - IQR*3 - low_limit:
                                Fault_3_risk.append(-4)
                                MLP_outliers1.append(['Fault_risk',-4]) 
                                Fault_3_risk_time.append(run)
                            elif main_KPI[-1] < MLP1_prediction - IQR*2 - low_limit:
                                Fault_3_risk.append(-3)
                                MLP_outliers1.append(['Fault_risk',-3]) 
                                Fault_3_risk_time.append(run)
                            elif main_KPI[-1] < MLP1_prediction - IQR - low_limit:
                                Fault_3_risk.append(-2)
                                MLP_outliers1.append(['Fault_risk',-2])  
                                Fault_3_risk_time.append(run)
                            elif main_KPI[-1] < MLP1_prediction - IQR:
                                Fault_3_risk.append(-1)    
                                MLP_outliers1.append(['Fault_risk',-1])
                                Fault_3_risk_time.append(run)
                            else:
                                Fault_3_risk.append(0)  
                                MLP_outliers1.append(['Fault_risk',0])
                                Fault_3_risk_time.append(run)

        except:
            Fault_3_risk.append(0)  
            MLP_outliers1.append(['Error'])
            Fault_3_risk_time.append(run)
    else:
        Fault_3_risk.append(0) 
        MLP_outliers1.append(['Low number of points'])    
        Fault_3_risk_time.append(run)

    if Fault_3_risk_time[-1] != run:
        Fault_3_risk.append(0)  
        MLP_outliers1.append(['Missing run'])
        Fault_3_risk_time.append(run)     
       
    if Fault_3_method_run:
        if Fault_3_risk[-1] in Fault_3_threshold:
            Fault_3_faulty.append(1)
        else:
            Fault_3_faulty.append(0)    
    
    t4 = time.time()
    "##############################################"
    "###          Fault detection method 4      ###"
    "###     KPCA + Q-statistics (2 variables)  ###"
    "##############################################"  
    # Calculation for the probability of a fault
    if KPCA_min_points < len(main_KPI) and Fault_4_method_run:
        try:
            if run%KPCA_update == 0 or KPCA_min_points+1 == len(main_KPI):
                # Initialize the newest data for the main KPI and explanatory variables and remove the current point
                main_KPI_KPCA = main_KPI.copy()
                main_KPI_KPCA.pop()
                if run > KPCA_max_points:
                    main_KPI_KPCA = main_KPI_KPCA[-KPCA_max_points:]
                
                explanatory_variables1_KPCA = explanatory_variables1.copy()
                explanatory_variables1_KPCA.drop(explanatory_variables1_KPCA.tail(1).index, inplace=True)       
                if run > KPCA_max_points:
                    explanatory_variables1_KPCA.drop(explanatory_variables1_KPCA.head(len(explanatory_variables1_KPCA)-KPCA_max_points).index, inplace=True)
                
                explanatory_variables2_KPCA = explanatory_variables2.copy()
                explanatory_variables2_KPCA.drop(explanatory_variables2_KPCA.tail(1).index, inplace=True)
                if run > KPCA_max_points:
                    explanatory_variables2_KPCA.drop(explanatory_variables2_KPCA.head(len(explanatory_variables2_KPCA)-KPCA_max_points).index, inplace=True)
                
                index_remover_KPCA = []
                
                # Remove all nan samples before training
                for x in range(len(main_KPI_KPCA)):
                    if math.isnan(explanatory_variables1_KPCA[x]) or math.isnan(explanatory_variables2_KPCA[x]) or math.isnan(main_KPI_KPCA[x]):
                        index_remover_KPCA.append(x)
                index_remover_KPCA.reverse()
                for x in range(len(index_remover_KPCA)):
                    main_KPI_KPCA.pop(index_remover_KPCA[x])
                    explanatory_variables1_KPCA.pop(index_remover_KPCA[x])
                    explanatory_variables2_KPCA.pop(index_remover_KPCA[x])
                    
                # Create the X and y datasets
                KPCA_X = pd.DataFrame()
                KPCA_X['explanatory_variables1'] = explanatory_variables1_KPCA
                KPCA_X['explanatory_variables2'] = explanatory_variables2_KPCA
                KPCA_X['main_KPI'] = main_KPI_KPCA
                
                # Fit the KPCA model
                kpca = KernelPCA(n_components=KPCA_n_components,kernel=KPCA_kernel_type,n_jobs=KPCA_n_jobs)
                X_kpca = kpca.fit(KPCA_X)
                
                # Find how many principal components to keep, in order to account for the chosen explained variance
                KPCA_accounted_variance = 0
                for x in range(len(X_kpca.lambdas_)):
                    KPCA_accounted_variance += X_kpca.lambdas_[x]/sum(X_kpca.lambdas_)
                    KPCA_components_included = x+1
                    if KPCA_accounted_variance > KPCA_variance_limit:
                        break
                
                # fit the model using only enough principal components to fullfil the criteria for explained variance
                kpca_optimized = KernelPCA(n_components=KPCA_components_included,kernel=KPCA_kernel_type,n_jobs=KPCA_n_jobs)
                X_kpca_optimized = kpca_optimized.fit(KPCA_X)
                
                # Calculate the mean and inverse covariance matrix for the model
                X_kpca_mean, X_kpca_inv_cov = KPCA_mahalanobis_vars(X_kpca_optimized.alphas_)
                # Calculate the mahalanobis thresholds
                X_kpca_mahalanobis_threshold_95 = chi2.ppf(0.95, X_kpca_optimized.alphas_.shape[1])
                X_kpca_mahalanobis_threshold_99 = chi2.ppf(0.99, X_kpca_optimized.alphas_.shape[1])
                X_kpca_mahalanobis_threshold_999 = chi2.ppf(0.999, X_kpca_optimized.alphas_.shape[1])
                X_kpca_mahalanobis_threshold_9999 = chi2.ppf(0.9999, X_kpca_optimized.alphas_.shape[1])
                X_kpca_mahalanobis_threshold_99999 = chi2.ppf(0.99999, X_kpca_optimized.alphas_.shape[1])
            
            # Calculate the Mahalanobis distance for the current point
            KPCA_X_current = pd.DataFrame()
            KPCA_X_current['current_explanatory_variables1_KPCA'] = explanatory_variables1_KPCA.tail(1).copy()
            KPCA_X_current['current_explanatory_variables2_KPCA'] = explanatory_variables2_KPCA.tail(1).copy()     
            KPCA_X_current['current_main_KPI'] = main_KPI.copy().pop()
            
            X_kpca_sample = X_kpca_optimized.transform(KPCA_X_current)    
            X_kpca_sample_mahalanobis = mahalanobis(X_kpca_sample,X_kpca_mean,X_kpca_inv_cov)
            
            # Check the current MD for the current point against the thresholds
            if X_kpca_sample_mahalanobis > X_kpca_mahalanobis_threshold_99999:
                Fault_4_risk.append(5)
                Fault_4_risk_time.append(run)
            elif X_kpca_sample_mahalanobis > X_kpca_mahalanobis_threshold_9999:
                Fault_4_risk.append(4)
                Fault_4_risk_time.append(run)
            elif X_kpca_sample_mahalanobis > X_kpca_mahalanobis_threshold_999:
                Fault_4_risk.append(3)
                Fault_4_risk_time.append(run)
            elif X_kpca_sample_mahalanobis > X_kpca_mahalanobis_threshold_99:
                Fault_4_risk.append(2)
                Fault_4_risk_time.append(run)
            elif X_kpca_sample_mahalanobis > X_kpca_mahalanobis_threshold_95:
                Fault_4_risk.append(1)
                Fault_4_risk_time.append(run)
            else:
                Fault_4_risk.append(0)
                Fault_4_risk_time.append(run)
                
        except:
            Fault_4_risk.append(0)
            Fault_4_risk_time.append(run)
    else:
        Fault_4_risk.append(0)
        Fault_4_risk_time.append(run)
    
    if Fault_4_method_run:
        if Fault_4_risk[-1] in Fault_4_threshold:
            Fault_4_faulty.append(1)
        else:
            Fault_4_faulty.append(0)
    
    t5 = time.time()
    "##############################################"
    "###          Fault detection method 5      ###"
    "###  KPCA + Q-statistics (all variables)   ###"
    "##############################################"    
    # Calculation for the probability of a fault

    if KPCA_min_points < len(main_KPI) and Fault_5_method_run:
        try:
            if run%KPCA_update == 0 or KPCA_min_points+1 == len(main_KPI):        
                # Initialize the newest data for the main KPI and explanatory variables and remove the current point
                main_KPI_KPCA1 = main_KPI.copy()
                main_KPI_KPCA1.pop()
                if run > KPCA_max_points:
                    main_KPI_KPCA1 = main_KPI_KPCA1[-KPCA_max_points:]
                
                explanatory_variables_all_KPCA1 = explanatory_variables_all.copy()
                explanatory_variables_all_KPCA1.drop(explanatory_variables_all_KPCA1.tail(1).index, inplace=True)
                if run > KPCA_max_points:
                    explanatory_variables_all_KPCA1.drop(explanatory_variables_all_KPCA1.head(len(explanatory_variables_all_KPCA1)-KPCA_max_points).index, inplace=True)
                explanatory_variables_all_KPCA1.reset_index(inplace=True, drop=True)
                
                index_remover_KPCA1 = []
        
                # Remove all nan samples before training
                for x in range(len(main_KPI_KPCA1)):
                    if explanatory_variables_all_KPCA1.isna().any(axis=1)[x] or math.isnan(main_KPI_KPCA1[x]):
                        index_remover_KPCA1.append(x)
                index_remover_KPCA1.reverse()
                for x in range(len(index_remover_KPCA1)):
                    main_KPI_KPCA1.pop(index_remover_KPCA1[x])
                explanatory_variables_all_KPCA1.drop(index_remover_KPCA1,axis=0,inplace=True)
        
                # Create the X and y datasets
                KPCA1_X = explanatory_variables_all_KPCA1.copy()
                KPCA1_X['main_KPI'] = main_KPI_KPCA1.copy()
                
                # Fit the KPCA model
                kpca1 = KernelPCA(n_components=KPCA_n_components,kernel=KPCA_kernel_type,n_jobs=KPCA_n_jobs)
                X_kpca1 = kpca1.fit(KPCA1_X)

                # Find how many principal components to keep, in order to account for the chosen explained variance
                KPCA1_accounted_variance = 0
                for x in range(len(X_kpca1.lambdas_)):
                    KPCA1_accounted_variance += X_kpca1.lambdas_[x]/sum(X_kpca1.lambdas_)
                    KPCA1_components_included = x+1
                    if KPCA1_accounted_variance > KPCA_variance_limit:
                        break
                    
                # fit the model using only enough principal components to fullfil the criteria for explained variance
                kpca1_optimized = KernelPCA(n_components=KPCA1_components_included,kernel=KPCA_kernel_type,n_jobs=KPCA_n_jobs)
                X_kpca1_optimized = kpca1_optimized.fit(KPCA1_X)

                # Calculate the mean and inverse covariance matrix for the model
                X_kpca1_mean, X_kpca1_inv_cov = KPCA_mahalanobis_vars(X_kpca1_optimized.alphas_)
                # Calculate the mahalanobis thresholds
                X_kpca1_mahalanobis_threshold_95 = chi2.ppf(0.95, X_kpca1_optimized.alphas_.shape[1])
                X_kpca1_mahalanobis_threshold_99 = chi2.ppf(0.99, X_kpca1_optimized.alphas_.shape[1])
                X_kpca1_mahalanobis_threshold_999 = chi2.ppf(0.999, X_kpca1_optimized.alphas_.shape[1])
                X_kpca1_mahalanobis_threshold_9999 = chi2.ppf(0.9999, X_kpca1_optimized.alphas_.shape[1])
                X_kpca1_mahalanobis_threshold_99999 = chi2.ppf(0.99999, X_kpca1_optimized.alphas_.shape[1])
                
            # Calculate the Mahalanobis distance for the current point
            KPCA1_X_current = explanatory_variables_all_KPCA1.tail(1).copy()
            KPCA1_X_current['current_main_KPI'] = main_KPI_KPCA1.copy().pop()

            X_kpca1_sample = X_kpca1_optimized.transform(KPCA1_X_current)    
            X_kpca1_sample_mahalanobis = mahalanobis(X_kpca1_sample,X_kpca1_mean,X_kpca1_inv_cov)

            # Check the current MD for the current point against the thresholds
            if X_kpca1_sample_mahalanobis > X_kpca1_mahalanobis_threshold_99999:
                Fault_5_risk.append(5)
                Fault_5_risk_time.append(run)
            elif X_kpca1_sample_mahalanobis > X_kpca1_mahalanobis_threshold_9999:
                Fault_5_risk.append(4)
                Fault_5_risk_time.append(run)
            elif X_kpca1_sample_mahalanobis > X_kpca1_mahalanobis_threshold_999:
                Fault_5_risk.append(3)
                Fault_5_risk_time.append(run)
            elif X_kpca1_sample_mahalanobis > X_kpca1_mahalanobis_threshold_99:
                Fault_5_risk.append(2)
                Fault_5_risk_time.append(run)
            elif X_kpca1_sample_mahalanobis > X_kpca1_mahalanobis_threshold_95:
                Fault_5_risk.append(1)
                Fault_5_risk_time.append(run)
            else:
                Fault_5_risk.append(0)
                Fault_5_risk_time.append(run)

        except:
            Fault_5_risk.append(0)
            Fault_5_risk_time.append(run)
    else:
        Fault_5_risk.append(0)    
        Fault_5_risk_time.append(run)
    
    if Fault_5_method_run:
        if Fault_5_risk[-1] in Fault_5_threshold:
            Fault_5_faulty.append(1)
        else:
            Fault_5_faulty.append(0)
    
    
    t6 = time.time()
    "##############################################"
    "###          Fault detection method 6      ###"
    "###         Newest point outlier check     ###"
    "##############################################"    
    # Calculation for the probability of a fault
    Fault_6_detection = 0
    if Fault_6_method_run:
        try:
            for i in range(1,grid_dim_1_subdivision+1):
                if i == 1:
                    cond1 = explanatory_variables1[len(explanatory_variables1)-1] >= grid[i,0]-grid_dim_1_step
                else:
                    cond1 = explanatory_variables1[len(explanatory_variables1)-1] > grid[i,0]-grid_dim_1_step
                cond2 = explanatory_variables1[len(explanatory_variables1)-1] <= grid[i,0]
                if cond1[0] and cond2[0]:
                    for j in range(1,grid_dim_2_subdivision+1):
                        if j == 1:
                            cond3 = explanatory_variables2[len(explanatory_variables2)-1] >= grid[0,j]-grid_dim_2_step
                        else:
                            cond3 = explanatory_variables2[len(explanatory_variables2)-1] > grid[0,j]-grid_dim_2_step
                        cond4 = explanatory_variables2[len(explanatory_variables2)-1] <= grid[0,j]
                        if cond3[0] and cond4[0]:
                            low_limit = IQR_grid[i,j][0]
                            high_limit = IQR_grid[i,j][4]
                            IQR = (IQR_grid[i,j][3]-IQR_grid[i,j][1])*IQR_multiplier                    
                            if main_KPI[-1] < low_limit:
                                Fault_6 = low_limit - main_KPI[-1]
                            elif main_KPI[-1] > high_limit:
                                Fault_6 = main_KPI[-1] - high_limit
                            else:
                                Fault_6 = 0
                                
                            Fault_6_risk.append(Fault_6)
                            Fault_6_risk_time.append(run)
                            Fault_6_detection = 1
                            break
            if Fault_6_detection == 0:
                Fault_6_risk.append(0)
                Fault_6_risk_time.append(run)
        except:
            Fault_6_risk.append(0)
            Fault_6_risk_time.append(run)
            
    if Fault_6_method_run:
        if Fault_6_risk[-1] in Fault_6_threshold:
            Fault_6_faulty.append(1)
        else:
            Fault_6_faulty.append(0)
    
    t7 = time.time()    
    "#########################################################"
    "###          Fault detection method 7                 ###"
    "###  Normalized KPCA + Q-statistics (all variables)   ###"
    "#########################################################"   
    # Calculation for the probability of a fault

    if KPCA_min_points < len(main_KPI) and Fault_7_method_run:
        try:
            if run%KPCA_update == 0 or KPCA_min_points+1 == len(main_KPI):        
                # Initialize the newest data for the main KPI and explanatory variables and remove the current point
                #main_KPI_KPCA2 = main_KPI.copy()
                #main_KPI_KPCA2.pop()
                #if run > KPCA_max_points:
                #    main_KPI_KPCA2 = main_KPI_KPCA2[-KPCA_max_points:]
                
                explanatory_variables_all_KPCA2 = explanatory_variables_all.copy()
                explanatory_variables_all_KPCA2.drop(explanatory_variables_all_KPCA2.tail(1).index, inplace=True)
                if run > KPCA_max_points:
                    explanatory_variables_all_KPCA2.drop(explanatory_variables_all_KPCA2.head(len(explanatory_variables_all_KPCA2)-KPCA_max_points).index, inplace=True)
                explanatory_variables_all_KPCA2.reset_index(inplace=True, drop=True)
                
                index_remover_KPCA2 = []
        
                # Remove all nan samples before training
                for x in range(len(explanatory_variables_all_KPCA2)):
                    if explanatory_variables_all_KPCA2.isna().any(axis=1)[x]: # or math.isnan(main_KPI_KPCA2[x]):
                        index_remover_KPCA2.append(x)
                index_remover_KPCA2.reverse()
                #for x in range(len(index_remover_KPCA2)):
                #    main_KPI_KPCA2.pop(index_remover_KPCA2[x])
                explanatory_variables_all_KPCA2.drop(index_remover_KPCA2,axis=0,inplace=True)

                # Remove all no-change columns before training
                for column in explanatory_variables_all_KPCA2.columns:
                    if explanatory_variables_all_KPCA2[column].min() == explanatory_variables_all_KPCA2[column].max():
                        explanatory_variables_all_KPCA2.drop(columns=column,inplace=True)

                # Normalize the features
                #main_KPI_KPCA2_norm,main_KPI_KPCA2_norm_limit_min,main_KPI_KPCA2_norm_limit_max = MLP_normalizer_series(main_KPI_KPCA2,MLP_norm_limit_KPI)
                explanatory_variables_all_KPCA2_norm,explanatory_variables_all_KPCA2_norm_limit_min,explanatory_variables_all_KPCA2_norm_limit_max = MLP_normalizer_series(explanatory_variables_all_KPCA2,MLP_norm_limit_variables)
        
                # Create the X and y datasets
                KPCA2_X = explanatory_variables_all_KPCA2_norm
                #KPCA2_X['main_KPI'] = main_KPI_KPCA2_norm
                
                # Fit the KPCA model
                kpca2 = KernelPCA(n_components=KPCA_n_components,kernel=KPCA_kernel_type,n_jobs=KPCA_n_jobs)
                X_kpca2 = kpca2.fit(KPCA2_X)

                # Find how many principal components to keep, in order to account for the chosen explained variance
                KPCA2_accounted_variance = 0
                for x in range(len(X_kpca2.lambdas_)):
                    KPCA2_accounted_variance += X_kpca2.lambdas_[x]/sum(X_kpca2.lambdas_)
                    KPCA2_components_included = x+1
                    if KPCA2_accounted_variance > KPCA_variance_limit:
                        break
                    
                # fit the model using only enough principal components to fullfil the criteria for explained variance
                kpca2_optimized = KernelPCA(n_components=KPCA2_components_included,kernel=KPCA_kernel_type,n_jobs=KPCA_n_jobs)
                X_kpca2_optimized = kpca2_optimized.fit(KPCA2_X)

                # Calculate the mean and inverse covariance matrix for the model
                X_kpca2_mean, X_kpca2_inv_cov = KPCA_mahalanobis_vars(X_kpca2_optimized.alphas_)
                # Calculate the mahalanobis thresholds
                X_kpca2_mahalanobis_threshold_95 = chi2.ppf(0.95, X_kpca2_optimized.alphas_.shape[1])
                X_kpca2_mahalanobis_threshold_99 = chi2.ppf(0.99, X_kpca2_optimized.alphas_.shape[1])                    
                X_kpca2_mahalanobis_threshold_999 = chi2.ppf(0.999, X_kpca2_optimized.alphas_.shape[1])
                X_kpca2_mahalanobis_threshold_9999 = chi2.ppf(0.9999, X_kpca2_optimized.alphas_.shape[1])
                X_kpca2_mahalanobis_threshold_99999 = chi2.ppf(0.99999, X_kpca2_optimized.alphas_.shape[1])
            
            # Calculate the Mahalanobis distance for the current point
            
            current_explanatory_variables_all_KPCA2_temp = []
            for x in range(len(explanatory_variables_all_KPCA2.columns)):
                current_explanatory_variables_all_KPCA2_temp.append(MLP_normalizer_point(float(explanatory_variables_all[explanatory_variables_all.columns[x]][-1:]),explanatory_variables_all_KPCA2_norm_limit_min[x],explanatory_variables_all_KPCA2_norm_limit_max[x],0))
            current_explanatory_variables_all_KPCA2 = pd.DataFrame([current_explanatory_variables_all_KPCA2_temp])
            
            #main_KPI_KPCA2_norm = MLP_normalizer_series(main_KPI_KPCA2.copy().pop(),MLP_norm_limit_KPI)
            
            KPCA2_X_current = current_explanatory_variables_all_KPCA2
            #KPCA2_X_current['current_main_KPI'] = main_KPI_KPCA2_norm

            X_kpca2_sample = X_kpca2_optimized.transform(KPCA2_X_current)    
            X_kpca2_sample_mahalanobis = mahalanobis(X_kpca2_sample,X_kpca2_mean,X_kpca2_inv_cov)

            # Check the current MD for the current point against the thresholds
            if X_kpca2_sample_mahalanobis > X_kpca2_mahalanobis_threshold_99999:
                Fault_7_risk.append(5)
                Fault_7_risk_time.append(run)
            elif X_kpca2_sample_mahalanobis > X_kpca2_mahalanobis_threshold_9999:
                Fault_7_risk.append(4)
                Fault_7_risk_time.append(run)
            elif X_kpca2_sample_mahalanobis > X_kpca2_mahalanobis_threshold_999:
                Fault_7_risk.append(3)
                Fault_7_risk_time.append(run)
            elif X_kpca2_sample_mahalanobis > X_kpca2_mahalanobis_threshold_99:
                Fault_7_risk.append(2)
                Fault_7_risk_time.append(run)
            elif X_kpca2_sample_mahalanobis > X_kpca2_mahalanobis_threshold_95:
                Fault_7_risk.append(1)
                Fault_7_risk_time.append(run)
            else:
                Fault_7_risk.append(0)
                Fault_7_risk_time.append(run)

        except:
            Fault_7_risk.append(0)
            Fault_7_risk_time.append(run)
    
    
    else:
        Fault_7_risk.append(0)    
        Fault_7_risk_time.append(run)
      

    if Fault_7_method_run:
        if Fault_7_risk[-1] in Fault_7_threshold:
            Fault_7_faulty.append(1)
        else:
            Fault_7_faulty.append(0)
    
    t8 = time.time()        
    
    "#########################################################"
    "###          Fault detection method 8                 ###"
    "###                 HDBscan                           ###"
    "#########################################################"    
    # Calculation for the probability of a fault    
    
    if HDBscan_min_points < len(main_KPI) and Fault_8_method_run:
        try:
            if run%HDBscan_update == 0 or HDBscan_min_points+1 == len(main_KPI):
                # Initialize the newest data for the main KPI and explanatory variables and remove the current point
                main_KPI_HDBscan = main_KPI.copy()
                main_KPI_HDBscan.pop()
                if run > HDBscan_max_points:
                    main_KPI_HDBscan = main_KPI_HDBscan[-HDBscan_max_points:]
                
                explanatory_variables1_HDBscan = explanatory_variables1.copy()
                explanatory_variables1_HDBscan.drop(explanatory_variables1_HDBscan.tail(1).index, inplace=True)       
                if run > HDBscan_max_points:
                    explanatory_variables1_HDBscan.drop(explanatory_variables1_HDBscan.head(len(explanatory_variables1_HDBscan)-HDBscan_max_points).index, inplace=True)
                
                explanatory_variables2_HDBscan = explanatory_variables2.copy()
                explanatory_variables2_HDBscan.drop(explanatory_variables2_HDBscan.tail(1).index, inplace=True)
                if run > HDBscan_max_points:
                    explanatory_variables2_HDBscan.drop(explanatory_variables2_HDBscan.head(len(explanatory_variables2_HDBscan)-HDBscan_max_points).index, inplace=True)
                
                index_remover_HDBscan = []
                
                # Remove all nan samples before training
                for x in range(len(main_KPI_HDBscan)):
                    if math.isnan(explanatory_variables1_HDBscan[x]) or math.isnan(explanatory_variables2_HDBscan[x]) or math.isnan(main_KPI_HDBscan[x]):
                        index_remover_HDBscan.append(x)
                index_remover_HDBscan.reverse()
                for x in range(len(index_remover_HDBscan)):
                    main_KPI_HDBscan.pop(index_remover_HDBscan[x])
                    explanatory_variables1_HDBscan.pop(index_remover_HDBscan[x])
                    explanatory_variables2_HDBscan.pop(index_remover_HDBscan[x])
                    
                # Create the X and y datasets
                HDBscan_X = pd.DataFrame()
                HDBscan_X['explanatory_variables1'] = explanatory_variables1_HDBscan
                HDBscan_X['explanatory_variables2'] = explanatory_variables2_HDBscan
                HDBscan_X['main_KPI'] = main_KPI_HDBscan   
    
                HDBscan_clusterer = hdbscan.HDBSCAN(min_cluster_size=HDBscan_min_cluster_points, prediction_data=True).fit(HDBscan_X)
            
            HDBscan_X_current = pd.DataFrame()
            HDBscan_X_current['explanatory_variables1'] = explanatory_variables1.copy().tail(1)
            HDBscan_X_current['explanatory_variables2'] = explanatory_variables2.copy().tail(1)
            HDBscan_X_current['main_KPI'] = main_KPI.copy().pop()          
            HDBscan_prediction_label,HDBscan_prediction_strength  = hdbscan.approximate_predict(HDBscan_clusterer,HDBscan_X_current)
            
            if HDBscan_prediction_label == -1:
                Fault_8_risk.append(-1)
                Fault_8_risk_time.append(run)
            elif HDBscan_prediction_label[0] >= 0 and HDBscan_prediction_strength[0] == 1:
                Fault_8_risk.append(0)
                Fault_8_risk_time.append(run)
            elif HDBscan_prediction_label[0] >= 0 and HDBscan_prediction_strength[0] > 0.8:
                Fault_8_risk.append(1)
                Fault_8_risk_time.append(run)
            elif HDBscan_prediction_label[0] >= 0 and HDBscan_prediction_strength[0] > 0.6:
                Fault_8_risk.append(2)
                Fault_8_risk_time.append(run)
            elif HDBscan_prediction_label[0] >= 0 and HDBscan_prediction_strength[0] > 0.4:
                Fault_8_risk.append(3)
                Fault_8_risk_time.append(run)
            else:
                Fault_8_risk.append(4)
                Fault_8_risk_time.append(run)
    
    
        except:
            Fault_8_risk.append(0)
            Fault_8_risk_time.append(run)
    else:
        Fault_8_risk.append(0)
        Fault_8_risk_time.append(run)    
    
    if Fault_8_method_run:
        if Fault_8_risk[-1] in Fault_8_threshold:
            Fault_8_faulty.append(1)
        else:
            Fault_8_faulty.append(0)    
    

    
    t9 = time.time()
    
    
    "#########################################################"
    "###          Fault detection method 9                 ###"
    "###                 HDBscan in grids                  ###"
    "#########################################################"    
    # Calculation for the probability of a fault    
    
    if HDBscan_min_points < len(main_KPI) and Fault_9_method_run:
        try:
            # Check which grid the current point is in
            for i in range(1,grid_dim_1_subdivision+1):
                if i == 1:
                    cond1 = explanatory_variables1[len(explanatory_variables1)-1] >= grid[i,0]-grid_dim_1_step
                else:
                    cond1 = explanatory_variables1[len(explanatory_variables1)-1] > grid[i,0]-grid_dim_1_step
                cond2 = explanatory_variables1[len(explanatory_variables1)-1] <= grid[i,0]
                if cond1[0] and cond2[0]:
                    HDBscan_grid_current_point_location_1 = i
            for j in range(1,grid_dim_2_subdivision+1):
                if j == 1:
                    cond3 = explanatory_variables2[len(explanatory_variables2)-1] >= grid[0,j]-grid_dim_2_step
                else:
                    cond3 = explanatory_variables2[len(explanatory_variables2)-1] > grid[0,j]-grid_dim_2_step
                cond4 = explanatory_variables2[len(explanatory_variables2)-1] <= grid[0,j]
                if cond3[0] and cond4[0]:
                    HDBscan_grid_current_point_location_2 = j
                    
            # Create the conditions for updating the model for the current gridspace        
            try:
                # condition is for old existing model
                HDBscan_grid_update_temp1 = run-HDBscan_grid_update[HDBscan_grid_current_point_location_1,HDBscan_grid_current_point_location_2] > HDBscan_update
            except:
                HDBscan_grid_update_temp1 = False         
            try:
                # condition is for no existing model
                HDBscan_grid_update_temp2 = (HDBscan_grid_current_point_location_1,HDBscan_grid_current_point_location_2) in HDBscan_grid_model.keys()
            except:
                HDBscan_grid_update_temp2 = True
            
            # Update the current gridspace model
            if HDBscan_grid_update_temp1 == True or HDBscan_grid_update_temp2 == False:
                # Initialize the newest data for the main KPI and explanatory variables in the gridspace and remove the current point
                main_KPI_HDBscan_grid = main_KPI.copy()
                main_KPI_HDBscan_grid.pop()
                if run > HDBscan_grid_max_points:
                    main_KPI_HDBscan_grid = main_KPI_HDBscan_grid[-HDBscan_grid_max_points:]
                
                explanatory_variables1_HDBscan_grid = explanatory_variables1.copy()
                explanatory_variables1_HDBscan_grid.drop(explanatory_variables1_HDBscan_grid.tail(1).index, inplace=True)       
                if run > HDBscan_grid_max_points:
                    explanatory_variables1_HDBscan_grid.drop(explanatory_variables1_HDBscan_grid.head(len(explanatory_variables1_HDBscan_grid)-HDBscan_grid_max_points).index, inplace=True)
                
                explanatory_variables2_HDBscan_grid = explanatory_variables2.copy()
                explanatory_variables2_HDBscan_grid.drop(explanatory_variables2_HDBscan_grid.tail(1).index, inplace=True)
                if run > HDBscan_grid_max_points:
                    explanatory_variables2_HDBscan_grid.drop(explanatory_variables2_HDBscan_grid.head(len(explanatory_variables2_HDBscan_grid)-HDBscan_grid_max_points).index, inplace=True)
                
                index_remover_HDBscan_grid = []
                
                # Remove all nan samples before training
                for x in range(len(main_KPI_HDBscan_grid)):
                    if math.isnan(explanatory_variables1_HDBscan_grid[x]) or math.isnan(explanatory_variables2_HDBscan_grid[x]) or math.isnan(main_KPI_HDBscan_grid[x]):
                        index_remover_HDBscan_grid.append(x)
                index_remover_HDBscan_grid.reverse()
                for x in range(len(index_remover_HDBscan_grid)):
                    main_KPI_HDBscan_grid.pop(index_remover_HDBscan_grid[x])
                    explanatory_variables1_HDBscan_grid.pop(index_remover_HDBscan_grid[x])
                    explanatory_variables2_HDBscan_grid.pop(index_remover_HDBscan_grid[x])
                    
                # Create the dataset
                HDBscan_grid_X = pd.DataFrame()
                HDBscan_grid_X['explanatory_variables1'] = explanatory_variables1_HDBscan_grid
                HDBscan_grid_X['explanatory_variables2'] = explanatory_variables2_HDBscan_grid
                HDBscan_grid_X['main_KPI'] = main_KPI_HDBscan_grid
                
                # Calculate the limits of the gridspace
                HDBscan_grid_current_point_location_1_min =  grid_dim_1_min + (grid_dim_1_step * (HDBscan_grid_current_point_location_1-1))
                HDBscan_grid_current_point_location_1_max =  grid_dim_1_min + (grid_dim_1_step * HDBscan_grid_current_point_location_1)
                HDBscan_grid_current_point_location_2_min =  grid_dim_2_min + (grid_dim_2_step * (HDBscan_grid_current_point_location_2-1))
                HDBscan_grid_current_point_location_2_max =  grid_dim_2_min + (grid_dim_2_step * HDBscan_grid_current_point_location_2)
                
                # Drop all rows that are outside of the current gridspace
                HDBscan_grid_X = HDBscan_grid_X[HDBscan_grid_X['explanatory_variables1'] <= HDBscan_grid_current_point_location_1_max]
                HDBscan_grid_X = HDBscan_grid_X[HDBscan_grid_X['explanatory_variables1'] >= HDBscan_grid_current_point_location_1_min]
                HDBscan_grid_X = HDBscan_grid_X[HDBscan_grid_X['explanatory_variables2'] <= HDBscan_grid_current_point_location_2_max]
                HDBscan_grid_X = HDBscan_grid_X[HDBscan_grid_X['explanatory_variables2'] >= HDBscan_grid_current_point_location_2_min]                

                # Train the model
                HDBscan_grid_clusterer = hdbscan.HDBSCAN(min_cluster_size=HDBscan_grid_min_cluster_points, prediction_data=True).fit(HDBscan_grid_X)
                
                # Add the model to the dict containing the models
                HDBscan_grid_model[HDBscan_grid_current_point_location_1,HDBscan_grid_current_point_location_2] = HDBscan_grid_clusterer
                
                # Update the model update time for the current gridspace
                HDBscan_grid_update[HDBscan_grid_current_point_location_1,HDBscan_grid_current_point_location_2] = run
                
            
            HDBscan_grid_X_current = pd.DataFrame()
            HDBscan_grid_X_current['explanatory_variables1'] = explanatory_variables1.copy().tail(1)
            HDBscan_grid_X_current['explanatory_variables2'] = explanatory_variables2.copy().tail(1)
            HDBscan_grid_X_current['main_KPI'] = main_KPI.copy().pop()          
            HDBscan_grid_prediction_label,HDBscan_grid_prediction_strength  = hdbscan.approximate_predict(HDBscan_grid_model[HDBscan_grid_current_point_location_1,HDBscan_grid_current_point_location_2],HDBscan_grid_X_current)
            
            if HDBscan_grid_prediction_label[0] == -1:
                Fault_9_risk.append(-1)
                Fault_9_risk_time.append(run)
            elif HDBscan_grid_prediction_label[0] >= 0 and HDBscan_grid_prediction_strength == 1:
                Fault_9_risk.append(0)
                Fault_9_risk_time.append(run)
            elif HDBscan_grid_prediction_label[0] >= 0 and HDBscan_grid_prediction_strength > 0.8:
                Fault_9_risk.append(1)
                Fault_9_risk_time.append(run)
            elif HDBscan_grid_prediction_label[0] >= 0 and HDBscan_grid_prediction_strength > 0.6:
                Fault_9_risk.append(2)
                Fault_9_risk_time.append(run)
            elif HDBscan_grid_prediction_label[0] >= 0 and HDBscan_grid_prediction_strength > 0.4:
                Fault_9_risk.append(3)
                Fault_9_risk_time.append(run)  
            else:
                Fault_9_risk.append(4)
                Fault_9_risk_time.append(run)
    
    
        except:
            Fault_9_risk.append(0)
            Fault_9_risk_time.append(run)
    else:
        Fault_9_risk.append(0)
        Fault_9_risk_time.append(run)    

    if Fault_9_method_run:
        if Fault_9_risk[-1] in Fault_9_threshold:
            Fault_9_faulty.append(1)
        else:
            Fault_9_faulty.append(0)
    
    t10 = time.time()    
    
    "#########################################################"
    "###          Fault detection method 10                ###"
    "###          HDBscan and IQR in grids                 ###"
    "#########################################################"    
    # Calculation for the probability of a fault       
    
    if HDBscan_min_points < len(main_KPI) and Fault_9_method_run and Fault_2_method_run and Fault_10_method_run:
        try:
            if Fault_9_risk[run-1] > 3 or Fault_9_risk[run-1] == -1:
                Fault_10_risk.append(Fault_2_risk_detected)
                Fault_10_risk_time.append(run)
            else:
                Fault_10_risk.append(0)
                Fault_10_risk_time.append(run)
        except:
            Fault_10_risk.append(0)
            Fault_10_risk_time.append(run)            
    
    else:
        Fault_10_risk.append(0)
        Fault_10_risk_time.append(run)   
        
    if Fault_9_method_run and Fault_2_method_run and Fault_10_method_run:
        if Fault_10_risk[-1] in Fault_10_threshold:
            Fault_10_faulty.append(1)
        else:
            Fault_10_faulty.append(0)

    t11 = time.time()  
        
    t00 = time.time()
    "#############################################"
    "###          Plotting                     ###"
    "#############################################"
    if run%run_plot_number == 0 and run_plot == 1:
        try:
            fig = plt.figure(figsize = [10,5])
            ax1 = fig.add_subplot(1,2,1, projection = '3d')
            ax2 = fig.add_subplot(3,2,2)
            ax3 = fig.add_subplot(3,2,4)
            ax4 = fig.add_subplot(3,2,6)
            plt.subplots_adjust(left=0.1,
                    bottom=0.1,
                    right=0.9,
                    top=0.9,
                    wspace=0.3,
                    hspace=0.2)
            
            ax1.axes.set_xlim3d(left = grid_dim_1_min, right = grid_dim_1_max) 
            ax1.axes.set_ylim3d(bottom = grid_dim_2_min, top = grid_dim_2_max) 
            ax1.axes.set_zlim3d(bottom = np.nanmin(main_KPI), top = np.nanmax(main_KPI))
            
            grid_dim_1_half_step = grid_dim_1_step/2
            grid_dim_2_half_step = grid_dim_2_step/2
            
            
            t01 = time.time()
            "#############################################"
            "###          Plot 1 (3d boxplot)          ###"
            "#############################################"          
            for i in range(1,grid_dim_1_subdivision+1):
                for j in range(1,grid_dim_2_subdivision+1):
                    x = [IQR_grid[i,0][0]-grid_dim_1_half_step]*2
                    y = [IQR_grid[0,j][0]-grid_dim_2_half_step]*2
                    z_low = IQR_grid[i,j][0:2]
                    z_high = IQR_grid[i,j][3:5]
                    
                    #Calculate all the points for the subdivision at main KPI levels minimum, Q25 and Q75
                    #the three letters after point_ indicates
                    #B for bottom, this is only used for the main KPI, and refers to the absolute minimum of it (bottom of z-axis)
                    #N for lower limit, this is only used for the main KPI, where it corresponds to the lower limit
                    #L for low, this is used for all three dimensions, for the main KPI this is the Q25
                    #M for medium, this is only used for the two subdivision grids
                    #H for high, this is used for all three dimensions, for the main KPI this is the Q75
                    
                    point_LLL = [IQR_grid[i,0][0]-grid_dim_1_half_step*2,IQR_grid[0,j][0]-grid_dim_2_half_step*2,IQR_grid[i,j][1]]
                    point_HLL = [IQR_grid[i,0][0],IQR_grid[0,j][0]-grid_dim_2_half_step*2,IQR_grid[i,j][1]]
                    point_LHL = [IQR_grid[i,0][0]-grid_dim_1_half_step*2,IQR_grid[0,j][0],IQR_grid[i,j][1]]
                    point_HHL = [IQR_grid[i,0][0],IQR_grid[0,j][0],IQR_grid[i,j][1]]
                    
                    point_LLH = [IQR_grid[i,0][0]-grid_dim_1_half_step*2,IQR_grid[0,j][0]-grid_dim_2_half_step*2,IQR_grid[i,j][3]]
                    point_HLH = [IQR_grid[i,0][0],IQR_grid[0,j][0]-grid_dim_2_half_step*2,IQR_grid[i,j][3]]
                    point_LHH = [IQR_grid[i,0][0]-grid_dim_1_half_step*2,IQR_grid[0,j][0],IQR_grid[i,j][3]]
                    point_HHH = [IQR_grid[i,0][0],IQR_grid[0,j][0],IQR_grid[i,j][3]]        
                    
                    point_LLB = [IQR_grid[i,0][0]-grid_dim_1_half_step*2,IQR_grid[0,j][0]-grid_dim_2_half_step*2,np.nanmin(main_KPI)]
                    point_HLB = [IQR_grid[i,0][0],IQR_grid[0,j][0]-grid_dim_2_half_step*2,np.nanmin(main_KPI)]
                    point_LHB = [IQR_grid[i,0][0]-grid_dim_1_half_step*2,IQR_grid[0,j][0],np.nanmin(main_KPI)]
                    point_HHB = [IQR_grid[i,0][0],IQR_grid[0,j][0],np.nanmin(main_KPI)]   
                    
                    point_MMN = [IQR_grid[i,0][0]-grid_dim_1_half_step,IQR_grid[0,j][0]-grid_dim_2_half_step,IQR_grid[i,j][0]]
                    point_MMB = [IQR_grid[i,0][0]-grid_dim_1_half_step,IQR_grid[0,j][0]-grid_dim_2_half_step,np.nanmin(main_KPI)]
                    
                    #Plots the square in the minimum of the z-axis, it shows a color corresponding to the average of the main KPI for that subdivision
                    bottom_points = [[point_LLB,point_HLB,point_HHB,point_LHB,point_LLB]]
                    
                    #Generate the color for the square
                    RGB_red = [1,0,0]
                    RGB_yellow = [1,1,0]
                    RGB_green = [0,1,0]
                    
                    RGB_bottom = np.nanmin(main_KPI)
                    RGB_mid = np.nanmin(main_KPI)+((np.nanmax(main_KPI)-np.nanmin(main_KPI))/2)
                    RGB_top = np.nanmax(main_KPI)
                    RGB_interval = RGB_top - RGB_bottom
                    
                    if GP == 'high':
                        if IQR_grid[i,j][2]>RGB_mid:
                            color_r = ((RGB_top-IQR_grid[i,j][2])/(RGB_interval/2))
                            color_g = 1
                            color_b = 0
                        else:
                            color_r = 1
                            color_g = (1-((RGB_mid-IQR_grid[i,j][2])/(RGB_interval/2)))
                            color_b = 0
                    elif GP == 'middle':
                        if IQR_grid[i,j][2]>GP_middle_point:
                            color_r = (1-(RGB_top-IQR_grid[i,j][2])/(RGB_top-GP_middle_point))
                            color_g = ((RGB_top-IQR_grid[i,j][2])/(RGB_top-GP_middle_point))
                            color_b = 0
                        else:
                            color_r = 0
                            color_g = ((IQR_grid[i,j][2]-RGB_bottom)/(GP_middle_point-RGB_bottom))
                            color_b = (1-(IQR_grid[i,j][2]-RGB_bottom)/(GP_middle_point-RGB_bottom))
                    elif GP == 'low':
                        if IQR_grid[i,j][2]<RGB_mid:
                            color_r = ((IQR_grid[i,j][2]-RGB_bottom)/(RGB_interval/2))
                            color_g = 1
                            color_b = 0
                        else:
                            color_r = 1
                            color_g = (1-((IQR_grid[i,j][2]-RGB_mid)/(RGB_interval/2)))
                            color_b = 0
                    
                    
                    if np.isnan(color_r) or np.isnan(color_g):
                        square_color = [0.502,0.502,0.502,0.8]
                    else:
                        square_color = [color_r,color_g,color_b,0.8]
                    
                    ax1.add_collection3d(Poly3DCollection(bottom_points, linewidths=1, edgecolors='k', facecolors=square_color))
                    
                    if len(IQR_grid[i,j][:])>outlier_bottom_limit+5: # is only activated for the subdivision grid which indicate faults
                        #Plots the points for lower limit (IQR*1.5), Q25, Q50, Q75 and upper limit (IQR*1.5)
                        ax1.scatter(IQR_grid[i,0][0]-grid_dim_1_half_step,IQR_grid[0,j][0]-grid_dim_2_half_step,IQR_grid[i,j][0],c='b',marker='_')
                        ax1.scatter(IQR_grid[i,0][0]-grid_dim_1_half_step,IQR_grid[0,j][0]-grid_dim_2_half_step,IQR_grid[i,j][2],c='k',marker='_')
                        ax1.scatter(IQR_grid[i,0][0]-grid_dim_1_half_step,IQR_grid[0,j][0]-grid_dim_2_half_step,IQR_grid[i,j][4],c='m',marker='_')
                        
                        #Plots the outliers
                        ax1.scatter(IQR_grid[i,0][0]-grid_dim_1_half_step,IQR_grid[0,j][0]-grid_dim_2_half_step,IQR_grid[i,j][5:],c='r',marker='*',s=2)
                        
                        #Plots the lines between the limits and the box
                        ax1.plot(x,y,z_low,c='k')
                        ax1.plot(x,y,z_high,c='k')
                        
                        #Plots the box, it covers between Q25 and Q75 and the entire grid square
                        box_points = [[point_LLL,point_HLL,point_HHL,point_LHL],
                                  [point_LLH,point_HLH,point_HHH,point_LHH],
                                  [point_LLL,point_LHL,point_LHH,point_LLH],
                                  [point_HLL,point_HHL,point_HHH,point_HLH],
                                  [point_LLL,point_LLH,point_HLH,point_HLL],
                                  [point_LHL,point_LHH,point_HHH,point_HHL]]
                        ax1.add_collection3d(Poly3DCollection(box_points, facecolors='cyan', linewidths=0.1, edgecolors='k', alpha=.10))
                        
                        #Plots the leading lines to better indicate which subdivision square the data is in, plotted between Q25 and the bottom
                        line_points = [[point_MMN,point_MMB]]
                        ax1.add_collection3d(Line3DCollection(line_points, linewidths=0.5, colors='r', linestyles='solid'))
            
            # Sets the names of the different axis
            ax1.set_zlabel(main_KPI_label, fontsize=6)                 
            ax1.set_xlabel(explanatory_variables_label1, fontsize=6)         
            ax1.set_ylabel(explanatory_variables_label2, fontsize=6)     
            ax1.set_title(Title+'\n'+str(Data['Time'][run]))
            
            # Adjust the x tick values
            xticks_value=[grid_dim_1_min]

            for x in range(1,grid_dim_1_subdivision+1):
                xticks_value.append(IQR_grid[x,0][0])

            # Adjust the y tick values
            yticks_value=[grid_dim_2_min]

            for y in range(1,grid_dim_2_subdivision+1):
                yticks_value.append(IQR_grid[0,y][0])

            # Sets the adjusted tick values    
            ax1.set_xticks(xticks_value)
            ax1.set_yticks(yticks_value)
            ax1.tick_params(axis='x', which='major', labelsize=10, rotation=60, pad=-5)
            ax1.tick_params(axis='y', which='major', labelsize=10, rotation=-45, pad=-4)
            ax1.tick_params(axis='z', which='major', labelsize=10, rotation=0, pad=0)
            
            # adjust the position of the tick labels, so they are placed logically
            xtick_offset_x = 0.2
            xtick_offset_y = 0.2
            for label in ax1.get_xticklabels():
                label_pos_x_x = label.get_position()[0]+xtick_offset_x
                label_pos_x_y = label.get_position()[1]+xtick_offset_y
                label_pos_x=(label_pos_x_x,label_pos_x_y)
                label.set_position(label_pos_x)
            
            t02 = time.time()
            "######################################"
            "### Plot 2 (fault indicator)       ###"
            "######################################"             
            
            Data_available = Data[:run]
            ax2.plot(Data_available['Time'][-min(run,FD_plot_number_of_points):-1],fault_status[-min(run,FD_plot_number_of_points):-1])        
            ax2.set_ylabel('Fault', fontsize=6)  
            ax2.set_ylim(min(fault_data),max(fault_data))
            ax2.set_xlim(min(Data_available['Time'][-min(run,FD_plot_number_of_points):-1]),max(Data_available['Time'][-min(run,FD_plot_number_of_points):-1]))
            #ax2.tick_params(axis='x', which='major', labelsize=6, rotation=45, pad=-5)
            ax2.tick_params(
                axis='x',          # changes apply to the x-axis
                which='both',      # both major and minor ticks are affected
                bottom=False,      # ticks along the bottom edge are off
                top=False,         # ticks along the top edge are off
                labelbottom=False) # labels along the bottom edge are off
        
            t03 = time.time()
            "######################################"
            "### Plot 3 (fault probability)     ###"
            "######################################"             
            if plot_3_type == 'risk':
                if Fault_1_method_run:
                    ax3.plot(Data_available['Time'][-min(run,FD_plot_number_of_points):-1],Fault_1_risk[-min(run,FD_plot_number_of_points):-1],c='b',linestyle='-',label='FD method 1')
                if Fault_2_method_run:
                    ax3.plot(Data_available['Time'][-min(run,FD_plot_number_of_points):-1],Fault_2_risk[-min(run,FD_plot_number_of_points):-1],c='r',linestyle='-',label='FD method 2')
                if Fault_3_method_run:
                    ax3.plot(Data_available['Time'][-min(run,FD_plot_number_of_points):-1],Fault_3_risk[-min(run,FD_plot_number_of_points):-1],c='k',linestyle='-',label='FD method 3')
                if Fault_4_method_run:
                    ax3.plot(Data_available['Time'][-min(run,FD_plot_number_of_points):-1],Fault_4_risk[-min(run,FD_plot_number_of_points):-1],c='g',linestyle='-',label='FD method 4')
                if Fault_5_method_run:
                    ax3.plot(Data_available['Time'][-min(run,FD_plot_number_of_points):-1],Fault_5_risk[-min(run,FD_plot_number_of_points):-1],c='y',linestyle='-',label='FD method 5')
                if Fault_6_method_run:
                    ax3.plot(Data_available['Time'][-min(run,FD_plot_number_of_points):-1],Fault_6_risk[-min(run,FD_plot_number_of_points):-1],c='b',linestyle='--',label='FD method 6')
                if Fault_7_method_run:
                    ax3.plot(Data_available['Time'][-min(run,FD_plot_number_of_points):-1],Fault_7_risk[-min(run,FD_plot_number_of_points):-1],c='r',linestyle='--',label='FD method 7')
                if Fault_8_method_run:
                    ax3.plot(Data_available['Time'][-min(run,FD_plot_number_of_points):-1],Fault_8_risk[-min(run,FD_plot_number_of_points):-1],c='k',linestyle='--',label='FD method 8')
                if Fault_9_method_run:
                    ax3.plot(Data_available['Time'][-min(run,FD_plot_number_of_points):-1],Fault_9_risk[-min(run,FD_plot_number_of_points):-1],c='g',linestyle='--',label='FD method 9')
                if Fault_10_method_run:
                    ax3.plot(Data_available['Time'][-min(run,FD_plot_number_of_points):-1],Fault_10_risk[-min(run,FD_plot_number_of_points):-1],c='y',linestyle='--',label='FD method 10')
            elif plot_3_type == 'fault':
                if Fault_1_method_run:
                    ax3.plot(Data_available['Time'][-min(run,FD_plot_number_of_points):-1],Fault_1_faulty[-min(run,FD_plot_number_of_points):-1],c='b',linestyle='-',label='FD method 1')
                if Fault_2_method_run:
                    ax3.plot(Data_available['Time'][-min(run,FD_plot_number_of_points):-1],Fault_2_faulty[-min(run,FD_plot_number_of_points):-1],c='r',linestyle='-',label='FD method 2')
                if Fault_3_method_run:
                    ax3.plot(Data_available['Time'][-min(run,FD_plot_number_of_points):-1],Fault_3_faulty[-min(run,FD_plot_number_of_points):-1],c='k',linestyle='-',label='FD method 3')
                if Fault_4_method_run:
                    ax3.plot(Data_available['Time'][-min(run,FD_plot_number_of_points):-1],Fault_4_faulty[-min(run,FD_plot_number_of_points):-1],c='g',linestyle='-',label='FD method 4')
                if Fault_5_method_run:
                    ax3.plot(Data_available['Time'][-min(run,FD_plot_number_of_points):-1],Fault_5_faulty[-min(run,FD_plot_number_of_points):-1],c='y',linestyle='-',label='FD method 5')
                if Fault_6_method_run:
                    ax3.plot(Data_available['Time'][-min(run,FD_plot_number_of_points):-1],Fault_6_faulty[-min(run,FD_plot_number_of_points):-1],c='b',linestyle='--',label='FD method 6')
                if Fault_7_method_run:
                    ax3.plot(Data_available['Time'][-min(run,FD_plot_number_of_points):-1],Fault_7_faulty[-min(run,FD_plot_number_of_points):-1],c='r',linestyle='--',label='FD method 7')
                if Fault_8_method_run:
                    ax3.plot(Data_available['Time'][-min(run,FD_plot_number_of_points):-1],Fault_8_faulty[-min(run,FD_plot_number_of_points):-1],c='k',linestyle='--',label='FD method 8')
                if Fault_9_method_run:
                    ax3.plot(Data_available['Time'][-min(run,FD_plot_number_of_points):-1],Fault_9_faulty[-min(run,FD_plot_number_of_points):-1],c='g',linestyle='--',label='FD method 9')
                if Fault_10_method_run:
                    ax3.plot(Data_available['Time'][-min(run,FD_plot_number_of_points):-1],Fault_10_faulty[-min(run,FD_plot_number_of_points):-1],c='y',linestyle='--',label='FD method 10')
            
            
            ax3.legend(loc='upper left',fontsize='x-small')
            
            #ax3.set_xlabel('Time', fontsize=6) 
            ax3.set_xlim(min(Data_available['Time'][-min(run,FD_plot_number_of_points):-1]),max(Data_available['Time'][-min(run,FD_plot_number_of_points):-1]))
            #ax3.tick_params(axis='x', which='major', labelsize=6, rotation=45, pad=-5)
            ax3.tick_params(
                axis='x',          # changes apply to the x-axis
                which='both',      # both major and minor ticks are affected
                bottom=False,      # ticks along the bottom edge are off
                top=False,         # ticks along the top edge are off
                labelbottom=False) # labels along the bottom edge are off            
            
            
            t04 = time.time()
            "######################################"
            "### Plot 4 (plot of raw data)      ###"
            "######################################"  
            ax4.plot(Data_available['Time'][-min(run,FD_plot_number_of_points):-1],main_KPI[-min(run,FD_plot_number_of_points):-1]*plot_main_KPI_multiplier,c='k',label=main_KPI_label)
            ax4.plot(Data_available['Time'][-min(run,FD_plot_number_of_points):-1],explanatory_variables1[-min(run,FD_plot_number_of_points):-1]*plot_explanatory_variable_multiplier1,c='b',label=explanatory_variables_label1)
            ax4.plot(Data_available['Time'][-min(run,FD_plot_number_of_points):-1],explanatory_variables2[-min(run,FD_plot_number_of_points):-1]*plot_explanatory_variable_multiplier2,c='r',label=explanatory_variables_label2)
            
            ax4.legend(loc='upper left',fontsize='x-small')
            ax4.set_xlabel('Time', fontsize=6) 
            ax4.set_xlim(min(Data_available['Time'][-min(run,FD_plot_number_of_points):-1]),max(Data_available['Time'][-min(run,FD_plot_number_of_points):-1]))
            ax4.tick_params(axis='x', which='major', labelsize=6, rotation=45, pad=-5)
            
            t05 = time.time()
            "######################################"
            "### Printing and saving the plot   ###"
            "######################################"            
            t001 = time.time()
            if plot_save == 1:
                save_path = os.getcwd()+'\\'+save_folder
                save_name = Title+'_'+str(Data['Time'][run].date())+'_'+str(Data['Time'][run].hour)+'-'+str(Data['Time'][run].minute)+'-'+str(Data['Time'][run].second)+'.png'
                fig.savefig(os.path.join(save_path,save_name))
            if plot_display == 0:
                plt.close()
            else:
                plt.show()
                plt.pause(0.05)
                plt.close()
            
            t002 = time.time()
            print('run:'+str(run)+' was plotted, '+str(run-end_point)+' remaining')
            
            if see_time == 1:
                print('Initiation took             '+str(round(t1-t0,1))+' seconds')
                print('FD method 1 took            '+str(round(t2-t1,1))+' seconds')
                print('FD method 2 took            '+str(round(t3-t2,1))+' seconds')
                print('FD method 3 took            '+str(round(t4-t3,1))+' seconds')
                print('FD method 4 took            '+str(round(t5-t4,1))+' seconds')
                print('FD method 5 took            '+str(round(t6-t5,1))+' seconds')
                print('FD method 6 took            '+str(round(t7-t6,1))+' seconds')
                print('FD method 7 took            '+str(round(t8-t7,1))+' seconds')
                print('FD method 8 took            '+str(round(t9-t8,1))+' seconds')
                print('FD method 9 took            '+str(round(t10-t9,1))+' seconds')
                print('FD method 10 took           '+str(round(t11-t10,1))+' seconds')
                
                print('Setting up the figure took  '+str(round(t01-t00,1))+' seconds')
                print('Plot 1 took                 '+str(round(t02-t01,1))+' seconds')
                print('Plot 2 took                 '+str(round(t03-t02,1))+' seconds')
                print('Plot 3 took                 '+str(round(t04-t03,1))+' seconds')
                print('Plot 4 took                 '+str(round(t05-t04,1))+' seconds')
                
                print('Saving and printing took    '+str(round(t002-t001,1))+' seconds')
            
                
                print('This timestep took          '+str(round(t002-t0,1))+' seconds')
                print('So far the script has taken '+str(round((t002-tstart)/60,1))+' minutes')
        except:
            continue

    if see_time == 1 and run_plot == 0:
        t002 = time.time()
        print('run:'+str(run)+' was finished, '+str(run-end_point)+' remaining')
        
        print('Initiation took             '+str(round(t1-t0,1))+' seconds')
        print('FD method 1 took            '+str(round(t2-t1,1))+' seconds')
        print('FD method 2 took            '+str(round(t3-t2,1))+' seconds')
        print('FD method 3 took            '+str(round(t4-t3,1))+' seconds')
        print('FD method 4 took            '+str(round(t5-t4,1))+' seconds')
        print('FD method 5 took            '+str(round(t6-t5,1))+' seconds')
        print('FD method 6 took            '+str(round(t7-t6,1))+' seconds')
        print('FD method 7 took            '+str(round(t8-t7,1))+' seconds')
        print('FD method 8 took            '+str(round(t9-t8,1))+' seconds')
        print('FD method 9 took            '+str(round(t10-t9,1))+' seconds')
        print('FD method 10 took           '+str(round(t11-t10,1))+' seconds')
        print('This timestep took          '+str(round(t002-t0,1))+' seconds')
        print('So far the script has taken '+str(round((t002-tstart)/60,1))+' minutes')


Fault_method_results = pd.DataFrame()
Fault_method_results['Time'] = Data_time[starting_point:run+1]
Fault_method_results['Fault'] = fault_data[starting_point:run+1]
if len(Fault_1_risk) == len(Fault_method_results):
    Fault_method_results['Fault_method_1_result'] = Fault_1_risk
if len(Fault_2_risk) == len(Fault_method_results):
    Fault_method_results['Fault_method_2_result'] = Fault_2_risk
if len(Fault_3_risk) == len(Fault_method_results):
    Fault_method_results['Fault_method_3_result'] = Fault_3_risk
if len(Fault_4_risk) == len(Fault_method_results):
    Fault_method_results['Fault_method_4_result'] = Fault_4_risk
if len(Fault_5_risk) == len(Fault_method_results):
    Fault_method_results['Fault_method_5_result'] = Fault_5_risk
if len(Fault_6_risk) == len(Fault_method_results):
    Fault_method_results['Fault_method_6_result'] = Fault_6_risk
if len(Fault_7_risk) == len(Fault_method_results):
    Fault_method_results['Fault_method_7_result'] = Fault_7_risk
if len(Fault_8_risk) == len(Fault_method_results):
    Fault_method_results['Fault_method_8_result'] = Fault_8_risk
if len(Fault_9_risk) == len(Fault_method_results):
    Fault_method_results['Fault_method_9_result'] = Fault_9_risk
if len(Fault_10_risk) == len(Fault_method_results):
    Fault_method_results['Fault_method_10_result'] = Fault_10_risk


Fault_method_results_bool = pd.DataFrame()
Fault_method_results_bool['Time'] = Data_time[starting_point:run+1]
Fault_method_results_bool['Fault'] = fault_data[starting_point:run+1]
if len(Fault_1_faulty) == len(Fault_method_results_bool):
    Fault_method_results_bool['Fault_method_1_result_bool'] = Fault_1_faulty
if len(Fault_2_faulty) == len(Fault_method_results_bool):
    Fault_method_results_bool['Fault_method_2_result_bool'] = Fault_2_faulty
if len(Fault_3_faulty) == len(Fault_method_results_bool):
    Fault_method_results_bool['Fault_method_3_result_bool'] = Fault_3_faulty
if len(Fault_4_faulty) == len(Fault_method_results_bool):
    Fault_method_results_bool['Fault_method_4_result_bool'] = Fault_4_faulty
if len(Fault_5_faulty) == len(Fault_method_results_bool):
    Fault_method_results_bool['Fault_method_5_result_bool'] = Fault_5_faulty
if len(Fault_6_faulty) == len(Fault_method_results_bool):
    Fault_method_results_bool['Fault_method_6_result_bool'] = Fault_6_faulty
if len(Fault_7_faulty) == len(Fault_method_results_bool):
    Fault_method_results_bool['Fault_method_7_result_bool'] = Fault_7_faulty
if len(Fault_8_faulty) == len(Fault_method_results_bool):
    Fault_method_results_bool['Fault_method_8_result_bool'] = Fault_8_faulty
if len(Fault_9_faulty) == len(Fault_method_results_bool):
    Fault_method_results_bool['Fault_method_9_result_bool'] = Fault_9_faulty
if len(Fault_10_faulty) == len(Fault_method_results_bool):
    Fault_method_results_bool['Fault_method_10_result_bool'] = Fault_10_faulty


print('Data_set: '+str(Data_set))
print('Dataset_subset: '+str(Dataset_subset))


Fault_method_results.to_excel(os.getcwd()+'\\Fault_method_results_temp.xlsx')
Fault_method_results_bool.to_excel(os.getcwd()+'\\Fault_method_results_bool_temp.xlsx')

